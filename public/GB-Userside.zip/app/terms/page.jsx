// pages/terms.js (or your preferred path)

import Footer from '@/components/Barcomponents/Footer';
import Navbar from '@/components/Barcomponents/Navbar';
import React from 'react';

// The 'isModal' prop will be true when this component is used in the modal
const Terms = ({ isModal = false }) => {
  const effectiveDate = new Date().toLocaleDateString('en-IN', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  return (
    <div>
      {/* Conditionally render Navbar and Footer only if it's NOT a modal */}
      {!isModal && <Navbar />}

      <div className="mx-auto p-4 sm:p-6 lg:p-8 font-sans">
        <h1 className="text-3xl sm:text-4xl font-bold bg-gradient-to-r from-[#263069] to-[#81E2FF] bg-clip-text text-transparent mb-6 text-center">Terms and Conditions</h1>
        <p className="text-gray-600 text-center mb-8">
          Effective Date: {effectiveDate}
        </p>

        <div className="bg-white shadow-lg rounded-lg p-6 sm:p-8">
          <p className="mb-6 text-gray-700 leading-relaxed">
            Welcome to Grab Bikes, operated by ADRENALINE RIDERS PVT LTD. By accessing our website or using our services, you agree to the following Terms & Conditions.
          </p>

          <Section title="1. Acceptance of Terms">
            <p>
              By using our website or booking a service, you confirm that you have read, understood, and agreed to these Terms. If you do not agree, please refrain from using our services. For concerns, contact: <a href="mailto:support@grabbikes.in" className="text-blue-600 hover:underline">support@grabbikes.in</a>
            </p>
          </Section>

          <Section title="2. Modifications">
            <p>
              We reserve the right to modify these Terms at any time. Updated versions will be posted on our Platform, and continued use signifies your acceptance.
            </p>
          </Section>

          <Section title="3. Eligibility">
            <p>To use our services, you must:</p>
            <ul className="list-disc list-inside ml-4 mt-2 space-y-1">
              <li>Be at least 18 years old</li>
              <li>Possess a valid driving license (original, not learner’s)</li>
              <li>Provide necessary identification and documentation at pickup</li>
            </ul>
          </Section>

          <Section title="4. User Responsibilities">
            <p>You agree not to:</p>
            <ul className="list-disc list-inside ml-4 mt-2 space-y-1">
              <li>Misuse or damage the rented vehicle</li>
              <li>Violate traffic laws or use the vehicle for illegal purposes</li>
              <li>Share your login or booking details with unauthorized persons</li>
              <li>Provide false information or forged documents</li>
            </ul>
          </Section>

          <Section title="5. Booking & Cancellations">
            <h4 className="font-semibold text-gray-800 mt-4 mb-2">Holding Time</h4>
            <p>
              Vehicles are held up to 2 hours post-scheduled pickup. After that, bookings are cancelled without refund.
            </p>
            <h4 className="font-semibold text-gray-800 mt-4 mb-2">Cancellation Policy</h4>
            <div className="overflow-x-auto">
              <table className="min-w-full bg-white border border-gray-200 rounded-lg">
                <thead>
                  <tr className="bg-gray-100">
                    <th className="py-2 px-4 border-b text-left text-sm font-medium text-gray-600">Time of Cancellation</th>
                    <th className="py-2 px-4 border-b text-left text-sm font-medium text-gray-600">Refund %</th>
                  </tr>
                </thead>
                <tbody>
                  <tr><td className="py-2 px-4 border-b text-gray-700">Before 1 hour of pickup</td><td className="py-2 px-4 border-b text-gray-700">80% refund</td></tr>
                  <tr><td className="py-2 px-4 border-b text-gray-700">Within 0–1 hour of pickup</td><td className="py-2 px-4 border-b text-gray-700">No refund</td></tr>
                  <tr><td className="py-2 px-4 border-b text-gray-700">After pickup or no-show</td><td className="py-2 px-4 border-b text-gray-700">No refund</td></tr>
                  <tr><td className="py-2 px-4 border-b text-gray-700">Vehicle not available</td><td className="py-2 px-4 border-b text-gray-700">Full refund</td></tr>
                  <tr><td className="py-2 px-4 text-gray-700">Don’t like vehicle</td><td className="py-2 px-4 text-gray-700">Full refund (with valid reason and photo proof via WhatsApp/email); else 20% charge</td></tr>
                </tbody>
              </table>
            </div>
          </Section>

          <Section title="6. Required Documents">
            <h4 className="font-semibold text-gray-800 mt-4 mb-2">For Indian Citizens:</h4>
            <ul className="list-disc list-inside ml-4 mt-2 space-y-1">
              <li>Valid original Driving License</li>
              <li>Original Aadhaar Card (with linked mobile number)</li>
              <li className="ml-6">If not linked: submit Passport or another official ID</li>
            </ul>
            <h4 className="font-semibold text-gray-800 mt-4 mb-2">For International Citizens:</h4>
            <ul className="list-disc list-inside ml-4 mt-2 space-y-1">
              <li>Original passport with valid visa</li>
              <li>Valid driving license + International Driving Permit</li>
            </ul>
          </Section>

          <Section title="7. Delivery Policy">
            <p>Free doorstep delivery for users within 2 km radius, between 11 AM – 8 PM, based on availability.</p>
          </Section>

          <Section title="8. Vehicle Condition, Damages, and Loss">
            <ul className="list-disc list-inside ml-4 mt-2 space-y-1">
              <li>Record a video at pickup covering full vehicle condition.</li>
              <li>Report any accident to support immediately.</li>
            </ul>
            <h4 className="font-semibold text-gray-800 mt-4 mb-2">Damage Cost Recovery Thresholds:</h4>
            <div className="overflow-x-auto">
              <table className="min-w-full bg-white border border-gray-200 rounded-lg">
                <thead><tr className="bg-gray-100"><th className="py-2 px-4 border-b text-left text-sm font-medium text-gray-600">Vehicle Type</th><th className="py-2 px-4 border-b text-left text-sm font-medium text-gray-600">Damage Recovery Starts From</th></tr></thead>
                <tbody>
                  <tr><td className="py-2 px-4 border-b text-gray-700">Scooty</td><td className="py-2 px-4 border-b text-gray-700">₹20,000</td></tr>
                  <tr><td className="py-2 px-4 border-b text-gray-700">Bike under (200cc)</td><td className="py-2 px-4 border-b text-gray-700">₹25,000</td></tr>
                  <tr><td className="py-2 px-4 text-gray-700">Bike over (400cc)</td><td className="py-2 px-4 text-gray-700">₹50,000</td></tr>
                </tbody>
              </table>
            </div>
            <ul className="list-disc list-inside ml-4 mt-2 space-y-1">
              <li>Theft: full cost of vehicle recoverable from user</li>
              <li>Lost keys: user bears cost of lockset replacement</li>
              <li>Towing charges (if any): borne by user</li>
            </ul>
          </Section>

          <Section title="9. Fuel Policy">
            <ul className="list-disc list-inside ml-4 mt-2 space-y-1">
              <li>Fuel is not included in rental.</li>
              <li>Vehicle will have minimum fuel to reach nearest petrol station.</li>
              <li>No refunds for unused fuel.</li>
            </ul>
          </Section>

          <Section title="10. Kilometer Limits">
            <p>Each vehicle comes with a defined km limit. Exceeding it will incur charges as per our policy. This is mentioned at the time of booking.</p>
          </Section>

          <Section title="11. Intellectual Property">
            <p>All website content (text, images, logos) is owned by ADRENALINE RIDERS PVT LTD or its licensors. Any unauthorized use or reproduction is strictly prohibited.</p>
          </Section>

          <Section title="12. Limitation of Liability">
            <p>We are not liable for:</p>
            <ul className="list-disc list-inside ml-4 mt-2 space-y-1">
              <li>Indirect or consequential damages</li>
              <li>Loss from third-party actions</li>
              <li>User non-compliance with terms or law</li>
            </ul>
            <p className="mt-2">All services are provided on an “as is” basis without warranties of uninterrupted access, accuracy, or safety.</p>
          </Section>

          <Section title="13. Governing Law">
            <p>These Terms are governed by the laws of India. Disputes are subject to the exclusive jurisdiction of the courts of Bengaluru, Karnataka.</p>
          </Section>

          <Section title="14. Contact Us">
            <p>For questions or issues, contact:</p>
            <p className="mt-2">
              📧 <a href="mailto:support@grabbikes.in" className="text-blue-600 hover:underline">support@grabbikes.in</a><br />
              📞 <a href="tel:+919148855444" className="text-blue-600 hover:underline">+919148855444</a>
            </p>
          </Section>
        </div>
      </div>
      {!isModal && <Footer />}
    </div>
  );
};

// Helper component for consistent section styling
const Section = ({ title, children }) => (
  <div className="mb-8">
    <h3 className="text-xl sm:text-2xl font-semibold text-gray-800 mb-4 border-b-2 border-blue-500 pb-2">
      {title}
    </h3>
    <div className="text-gray-700 leading-relaxed">
      {children}
    </div>
  </div>
);

export default Terms;