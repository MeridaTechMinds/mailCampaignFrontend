import Footer from "@/components/Barcomponents/Footer";
import Navbar from "@/components/Barcomponents/Navbar";
import Offersec1 from "@/components/Offercomponents/Offersec1";
import React from "react";

function Offer(){
    return(
        <div>
            <Navbar/>
            <Offersec1/>
            <Footer/>
        </div>
    )
}

export default Offer