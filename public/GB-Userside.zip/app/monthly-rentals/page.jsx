"use client"

import Footer from "@/components/Barcomponents/Footer"
import Navbar from "@/components/Barcomponents/Navbar"
import Question from "@/components/Barcomponents/Question"
import Rentalsec1 from "@/components/Rentalcomponents/Rentalsec1"
import Rentalsec2 from "@/components/Rentalcomponents/Rentalsec2"
import Rentalsec3 from "@/components/Rentalcomponents/Rentalsec3"
import Rentalsec4 from "@/components/Rentalcomponents/Rentalsec4"




function Monthlyrentals(){
    return(
        <div>
            <Navbar/>
            <Rentalsec1/>
            <Rentalsec2/>
            <Rentalsec3/>
            <Question/>
            <Rentalsec4/>
            <Footer/>
        </div>
    )
}

export default Monthlyrentals