"use client";
import { useState, Suspense } from 'react';
import { useSearchParams, useRouter } from 'next/navigation';
import Link from 'next/link';
import axios from 'axios';
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

function LoginComponent() {
  const [email, setEmail] = useState('');
  const [otp, setOtp] = useState('');
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);

  const router = useRouter();
  const searchParams = useSearchParams();
  const returnUrl = searchParams.get('returnUrl') || '/';

  const handleSendOtp = async (e) => {
    e.preventDefault();
    if (!email) {
      toast.error("Please enter a valid email address.");
      return;
    }
    try {
      setLoading(true);
      await axios.post(`${process.env.NEXT_PUBLIC_PORT}/user/send-otp`, { email });
      toast.success("OTP sent to your email address 📧");
      setStep(2);
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to send OTP');
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyOtp = async (e) => {
    e.preventDefault();
    try {
      setLoading(true);
     
      const response = await axios.post(`${process.env.NEXT_PUBLIC_PORT}/user/verify-otp`, {
        email,
        otp,
      });

      const user = response.data.user;

      sessionStorage.setItem('isLoggedIn', 'true');
      sessionStorage.setItem('userName', user.name || '');
      sessionStorage.setItem('userId', user.id);
      sessionStorage.setItem('userEmail', user.email); 
      sessionStorage.setItem('userData', JSON.stringify(user));

      toast.success("Login successful!");
      
      setTimeout(() => {
        router.push(returnUrl);
      }, 1000);
    } catch (err) {
      toast.error(err.response?.data?.message || 'OTP verification failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className='bg-gradient-to-r from-[#81E2FF] to-white h-screen flex justify-center items-center'>
      <div className="w-[90%] md:w-[30%] p-6 bg-white rounded-lg shadow-md">
        <h2 className="text-2xl font-bold mb-6 text-center">Sign In</h2>

        <form onSubmit={step === 1 ? handleSendOtp : handleVerifyOtp} className="space-y-4">
          <div>
            <label htmlFor="email" className="block mb-1 font-medium">Email Address</label>
            <input
              type="email"
              id="email"
              name="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              disabled={step === 2} 
              placeholder="Enter your email"
              className="w-full p-2 border rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          {step === 2 && (
            <div>
              <label htmlFor="otp" className="block mb-1 font-medium">Enter OTP</label>
              <input
                type="text"
                id="otp"
                name="otp"
                value={otp}
                onChange={(e) => setOtp(e.target.value)}
                required
                maxLength={6}
                className="w-full p-2 border rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Check your email for the OTP"
              />
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-blue-600 text-white py-2 px-4 rounded hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:opacity-50"
          >
            {loading
              ? step === 1
                ? 'Sending OTP...'
                : 'Verifying...'
              : step === 1
              ? 'Send OTP'
              : 'Verify & Login'}
          </button>
        </form>

        <div className="mt-4 text-center">
          <p>Don't have an account? <Link href="/signup" className="text-blue-600 hover:underline">Sign Up</Link></p>
        </div>

        <ToastContainer position="top-center" autoClose={3000} />
      </div>
    </div>
  );
}

export default function Login() {
  return (
    <Suspense fallback={<div>Loading...</div>}>
      <LoginComponent />
    </Suspense>
  );
}