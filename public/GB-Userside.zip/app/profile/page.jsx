"use client";

import { useEffect, useState } from 'react';
import { 
  FaUser, FaCalendarAlt, FaBiking, FaMapMarkerAlt, 
  FaClock, FaRupeeSign, FaWalking, FaMoneyBill, 
  FaLock, FaAccessibleIcon, FaMobile
} from 'react-icons/fa';
import Link from 'next/link';
import Navbar from '@/components/Barcomponents/Navbar';
import Footer from '@/components/Barcomponents/Footer';

function Profile() {
  const [userData, setUserData] = useState(null);
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const calculateDuration = (startDate, endDate) => {
    const start = new Date(startDate);
    const end = new Date(endDate);
    const diffTime = Math.abs(end - start);
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
    const diffHours = Math.ceil(diffTime / (1000 * 60 * 60));

    if (diffDays > 0) {
      return `${diffDays} day${diffDays !== 1 ? 's' : ''}`;
    } else if (diffHours > 0) {
      return `${diffHours} hour${diffHours !== 1 ? 's' : ''}`;
    } else {
      const diffMinutes = Math.round(diffTime / (1000 * 60));
      return `${diffMinutes} minute${diffMinutes !== 1 ? 's' : ''}`;
    }
  };

  useEffect(() => {
    const fetchUserDataAndBookings = async () => {
      try {
        // Fallback to localStorage if sessionStorage is empty, for persistence
        const user = JSON.parse(sessionStorage.getItem('userData') || localStorage.getItem('userData'));
        if (!user?.id) {
          throw new Error('User not authenticated. Please log in.');
        }
        setUserData(user);

        const response = await fetch(`${process.env.NEXT_PUBLIC_PORT}/userbookings/${user.id}`);
        if (!response.ok) {
          throw new Error('Failed to fetch bookings');
        }
        const data = await response.json();
        setBookings(data);
      } catch (err) {
        console.error('Error:', err);
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchUserDataAndBookings();
  }, []);

  const formatDate = (dateString) => {
    const options = { year: 'numeric', month: 'short', day: 'numeric' };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };

  const renderAccessories = (accessories) => {
    if (!accessories || accessories.length === 0) {
      return <p className="text-sm text-gray-500">No accessories</p>;
    }

    return (
      <ul className="space-y-2">
        {accessories.map((accessory) => (
          <li key={accessory._id} className="flex items-center text-sm text-gray-700">
            {accessory.name === 'Phone Holder' && <FaMobile className="mr-2 text-gray-500" />}
            {accessory.name === 'Lock' && <FaLock className="mr-2 text-gray-500" />}
            <span>{accessory.name} - <span className="font-semibold">₹{accessory.pricePerDay}</span>/day</span>
          </li>
        ))}
      </ul>
    );
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="animate-spin rounded-full h-16 w-16 border-t-4 border-b-4 border-blue-600"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 p-4">
        <div className="text-center p-8 max-w-md w-full bg-white rounded-xl shadow-lg">
          <div className="text-red-500 mb-4">
            <svg className="w-16 h-16 mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
            </svg>
          </div>
          <h2 className="text-2xl font-bold mb-3 text-gray-800">Oops! Something went wrong.</h2>
          <p className="text-gray-600 mb-6">{error}</p>
          <button 
            onClick={() => window.location.reload()}
            className="bg-blue-600 text-white px-6 py-2 rounded-lg font-semibold hover:bg-blue-700 transition-colors duration-300"
          >
            Try Again
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-gray-50 min-h-screen">
      <Navbar />
      <main className="max-w-7xl mx-auto p-4 sm:p-6 lg:p-8">
        <div className="space-y-8">
        
          {/* User Profile Card */}
          <div className="bg-white rounded-xl shadow-md p-6">
            <div className="flex flex-col sm:flex-row items-center space-y-4 sm:space-y-0 sm:space-x-6">
              <div className="flex-shrink-0 bg-blue-100 rounded-full p-4">
                <FaUser className="text-blue-600 text-3xl" />
              </div>
              <div className="text-center sm:text-left">
                <h1 className="text-2xl font-bold text-gray-800">{userData?.name || 'User Name'}</h1>
                <p className="text-gray-600">{userData?.email || 'user@example.com'}</p>
                <p className="text-gray-600 mt-1">
                  <span className="font-medium">Phone:</span> {userData?.phone || '+91 XXXXXXXXXX'}
                </p>
              </div>
            </div>
          </div>

          {/* Bookings Section */}
          <div className="bg-white rounded-xl shadow-md">
            <div className="p-6 border-b border-gray-200">
              <h2 className="text-2xl font-bold flex items-center text-gray-800">
                <FaCalendarAlt className="mr-3 text-blue-600" />
                My Bookings
              </h2>
            </div>

            {bookings.length === 0 ? (
              <div className="p-8 text-center">
                <FaBiking className="mx-auto text-5xl text-gray-300 mb-4" />
                <p className="text-lg text-gray-500 mb-6">You haven't booked any rides yet.</p>
                <Link href="/bikepackage">
                  <a className="inline-block bg-blue-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-blue-700 transition-transform duration-300 hover:scale-105">
                    Explore Bikes & Book Now
                  </a>
                </Link>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 p-6">
                {bookings.map((booking) => (
                  <div key={booking._id} className="bg-white rounded-lg border border-gray-200 overflow-hidden hover:shadow-lg transition-shadow duration-300 flex flex-col">
                    <div className="p-5 flex-grow">
                      {/* Header */}
                      <div className="flex items-start justify-between">
                        <div>
                           <h3 className="font-bold text-lg text-gray-900">
                            {booking.Bike?.brand} {booking.Bike?.name}
                           </h3>
                           <p className="text-sm text-gray-500 flex items-center mt-1">
                            <FaMapMarkerAlt className="mr-1.5" />
                            {booking.Bike?.location}
                           </p>
                        </div>
                        <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                          new Date(booking.endDate) < new Date() 
                            ? 'bg-green-100 text-green-800' 
                            : 'bg-yellow-100 text-yellow-800'
                        }`}>
                          {new Date(booking.endDate) < new Date() ? 'Completed' : 'Active'}
                        </span>
                      </div>

                      {/* Meta Details Grid */}
                      <div className="mt-6 grid grid-cols-2 gap-x-4 gap-y-5 text-sm">
                        <div className="flex items-start">
                          <FaCalendarAlt className="text-gray-400 mt-1 mr-3 flex-shrink-0" />
                          <div>
                            <p className="text-gray-500">Date</p>
                            <p className="font-semibold text-gray-700">{formatDate(booking.startDate)}</p>
                          </div>
                        </div>
                        <div className="flex items-start">
                          <FaClock className="text-gray-400 mt-1 mr-3 flex-shrink-0" />
                          <div>
                            <p className="text-gray-500">Duration</p>
                            <p className="font-semibold text-gray-700">{calculateDuration(booking.startDate, booking.endDate)}</p>
                          </div>
                        </div>
                         <div className="flex items-start col-span-2">
                          <FaAccessibleIcon className="text-gray-400 mt-1 mr-3 flex-shrink-0" />
                          <div>
                            <p className="text-gray-500 mb-1">Accessories</p>
                            {renderAccessories(booking.accessories)}
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    {/* Footer with Price */}
                    <div className="bg-gray-50 p-4 border-t border-gray-200 flex items-center justify-between">
                        <div>
                            <p className="text-sm text-gray-500">Amount Paid</p>
                            <p className="text-lg font-bold text-gray-800">₹{booking.amountPaid}</p>
                        </div>
                        <div className="text-right">
                           <p className="text-sm text-gray-500">Total Price</p>
                           <p className="text-lg font-bold text-green-600">
                             ₹{booking.totalprice}
                           </p>
                        </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}

export default Profile;