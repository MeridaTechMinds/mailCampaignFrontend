"use client";

import Navbar from "@/components/Barcomponents/Navbar";
import Homesec1 from "@/components/Homecomponents/Homesec1";
import Image from "next/image";
import { Stick_No_Bills } from "next/font/google";
import Homesec2 from "@/components/Homecomponents/Homesec2";
import Footer from "@/components/Barcomponents/Footer";
import Rentalsec4 from "@/components/Rentalcomponents/Rentalsec4";


const stickNoBills = Stick_No_Bills({
  subsets: ["latin"],
  weight: ["400", "600", "700", "800"], // choose weights you need
});

function Home() {

  return (
    <div className="relative  bg-dot">
      {/* Background and decorative elements */}
      {/* Vector background - hidden on mobile */}
      <Image
        src="/Vector 81.png"
        width={200}
        height={200}
        className="absolute top-0 right-0 z-10 hidden md:block md:w-1/2 lg:w-[38.8%]"
        alt="Background decoration"
        priority
      />
      <Navbar isLanding={true} />
      <div className="z-20 m-0 row min-h-[100vh] relative">
        <section className="  order-2 col-lg-6 lg:order-1 " >
          <Homesec1 />
        </section>
        <section className="flex order-1 relative lg:!order-2 col-lg-6 " >
          <article className=" m-auto relative py-10 lg:py-20 " >
            {/* Large text elements - hidden on mobile */}
            <div className="absolute w-full hidden lg:block top-0 z-10 -translate-x-1/2 left-1/2  " >
              <article className=" flex gap-2 " >
                <h1
                  className={` !bg-gradient-to-b
               !from-[#263069] !to-[#81E2FF] !bg-clip-text !text-transparent !text-[150px] lg:!text-[240px] xl:!text-[300px] z-20 fw-bold 
               ${stickNoBills.className}`}>
                  B
                </h1>

                <h1
                  className={`  text-white z-20 font-bold tracking-widest !text-[150px] lg:!text-[240px] xl:!text-[300px] 
                  ${stickNoBills.className}`}
                >
                  IKE               </h1>
              </article>
            </div>


            {/* Bike image - responsive positioning and sizing */}
            <Image
              src="/Jawabike pic.png"
              width={500}
              height={500}
              className="relative w-[95%] max-w-[300px] md:max-w-none z-30 "
              alt="Bike image"
              priority
            />
          </article>

        </section>
      </div>
      {/* <Homesec1 /> */}
      <Homesec2 />
      <Rentalsec4/>
      <Footer />

    </div >
  );
}

export default Home;