

import Footer from "@/components/Barcomponents/Footer"
import Navbar from "@/components/Barcomponents/Navbar"
import Term from "@/components/Barcomponents/Term"
import Paysec1 from "@/components/Paymentcomponent/Paysec1"
import { Suspense } from "react"


function Payment() {
    return (
            <div>
                <Navbar />
                <Paysec1 />
                 <Term/>
                <Footer />
            </div>
    )
}

export default Payment