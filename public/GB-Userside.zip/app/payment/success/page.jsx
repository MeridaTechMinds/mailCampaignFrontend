"use client"
import { useSearchParams } from "next/navigation"
import { useEffect, useState } from "react"
import Link from "next/link"
import { CheckCircle, CalendarDays, MapPin, Bike, CreditCard, Hash, Clock, FileText } from "lucide-react"

function SuccessPage() {
  const searchParams = useSearchParams()

  // State for all booking details from the URL
  const [bookingDetails, setBookingDetails] = useState({
    bookingId: '',
    bikeName: '',
    totalPrice: '',
    amountPaid: '',
    remainingAmount: '',
    paymentId: '',
    paymentMode: '',
    pickupDate: '',
    returnDate: '',
    pickupLocation: '',
    rentalDuration: ''
  });

  useEffect(() => {
    // --- Data Retrieval ---
    const pickupDateStr = decodeURIComponent(searchParams.get('pickupDate') || '');
    const returnDateStr = decodeURIComponent(searchParams.get('returnDate') || '');
    const remainingAmountVal = searchParams.get('remainingAmount');

    // --- Duration Calculation ---
    let durationString = '';
    if (pickupDateStr && returnDateStr) {
      const start = new Date(pickupDateStr);
      const end = new Date(returnDateStr);
      let diff = end.getTime() - start.getTime();

      const days = Math.floor(diff / (1000 * 60 * 60 * 24));
      diff -= days * (1000 * 60 * 60 * 24);

      const hours = Math.floor(diff / (1000 * 60 * 60));
      diff -= hours * (1000 * 60 * 60);

      const minutes = Math.floor(diff / (1000 * 60));

      let parts = [];
      if (days > 0) parts.push(`${days} day${days > 1 ? 's' : ''}`);
      if (hours > 0) parts.push(`${hours} hour${hours > 1 ? 's' : ''}`);
      if (minutes > 0) parts.push(`${minutes} minute${minutes > 1 ? 's' : ''}`);
      durationString = parts.join(', ');
    }
    
    // --- Update State ---
    setBookingDetails({
      bookingId: searchParams.get('bookingId') || 'N/A',
      bikeName: decodeURIComponent(searchParams.get('bikeName') || 'Bike'),
      totalPrice: searchParams.get('totalPriceWithGST') || '0',
      amountPaid: searchParams.get('amountPaidOnline') || '0',
      remainingAmount: remainingAmountVal && parseFloat(remainingAmountVal) > 0 ? remainingAmountVal : '0',
      paymentId: searchParams.get('paymentId') || 'N/A',
      paymentMode: searchParams.get('paymentMode') || 'Online',
      pickupDate: pickupDateStr,
      returnDate: returnDateStr,
      pickupLocation: decodeURIComponent(searchParams.get('pickupLocation') || 'N/A'),
      rentalDuration: durationString || 'N/A'
    });

  }, [searchParams]);

  const formatDate = (dateString) => {
    if (!dateString) return "Not specified";
    return new Date(dateString).toLocaleString('en-US', { 
        weekday: 'short', year: 'numeric', month: 'short', 
        day: 'numeric', hour: '2-digit', minute: '2-digit', hour12: true 
    });
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-green-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-3xl mx-auto">
        <div className="text-center mb-8">
          <div className="mx-auto flex items-center justify-center h-16 w-16 rounded-full bg-green-100 mb-4">
            <CheckCircle className="h-10 w-10 text-green-600" />
          </div>
          <h1 className="text-3xl font-extrabold text-gray-900 sm:text-4xl mb-2">
            Booking Confirmed!
          </h1>
          <p className="text-lg text-gray-600">
            Thank you for choosing us! Your booking summary is ready.
          </p>
        </div>

        <div className="bg-white shadow-xl rounded-lg overflow-hidden">
          <div className="bg-gradient-to-r from-blue-500 to-green-500 p-6 text-white">
            <h2 className="text-2xl font-bold">Your Adventure Awaits!</h2>
            <p className="opacity-90">Get ready to ride the {bookingDetails.bikeName}</p>
          </div>

          <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-6">
              
              {/* Column 1: Booking & Bike Info */}
              <div className="space-y-6">
                  {/* Booking ID */}
                  <div className="flex items-start">
                      <div className="flex-shrink-0 bg-yellow-100 p-3 rounded-lg"><Hash className="h-6 w-6 text-yellow-600" /></div>
                      <div className="ml-4">
                          <h3 className="text-lg font-medium text-gray-900">Booking Reference</h3>
                          <p className="mt-1 text-gray-600 font-mono">{bookingDetails.bookingId}</p>
                      </div>
                  </div>

                  {/* Bike Info */}
                  <div className="flex items-start">
                      <div className="flex-shrink-0 bg-blue-100 p-3 rounded-lg"><Bike className="h-6 w-6 text-blue-600" /></div>
                      <div className="ml-4">
                          <h3 className="text-lg font-medium text-gray-900">Bike Details</h3>
                          <p className="mt-1 text-gray-600 font-semibold">{bookingDetails.bikeName}</p>
                          <div className="flex items-center text-sm text-gray-500 mt-1">
                            <Clock size={16} className="mr-1.5"/>
                            <span>{bookingDetails.rentalDuration}</span>
                          </div>
                      </div>
                  </div>

                  {/* Location */}
                  <div className="flex items-start">
                      <div className="flex-shrink-0 bg-red-100 p-3 rounded-lg"><MapPin className="h-6 w-6 text-red-600" /></div>
                      <div className="ml-4">
                          <h3 className="text-lg font-medium text-gray-900">Pickup Location</h3>
                          <p className="mt-1 text-gray-600">{bookingDetails.pickupLocation}</p>
                      </div>
                  </div>
              </div>

              {/* Column 2: Dates & Payment */}
              <div className="space-y-6">
                  {/* Dates */}
                  <div className="flex items-start">
                      <div className="flex-shrink-0 bg-purple-100 p-3 rounded-lg"><CalendarDays className="h-6 w-6 text-purple-600" /></div>
                      <div className="ml-4">
                          <h3 className="text-lg font-medium text-gray-900">Rental Period</h3>
                          <p className="mt-1 text-gray-600 text-sm"><strong>From:</strong> {formatDate(bookingDetails.pickupDate)}</p>
                          <p className="text-gray-600 text-sm"><strong>To:</strong> {formatDate(bookingDetails.returnDate)}</p>
                      </div>
                  </div>

                  {/* Payment Details */}
                  <div className="flex items-start">
                      <div className="flex-shrink-0 bg-green-100 p-3 rounded-lg"><CreditCard className="h-6 w-6 text-green-600" /></div>
                      <div className="ml-4 w-full">
                          <h3 className="text-lg font-medium text-gray-900">Payment Summary</h3>
                          <div className="mt-2 space-y-2 text-sm">
                              <div className="flex justify-between">
                                  <span className="text-gray-600">Total Rent:</span>
                                  <span className="font-medium text-gray-800">₹{parseFloat(bookingDetails.totalPrice).toFixed(2)}</span>
                              </div>
                              <div className="flex justify-between">
                                  <span className="text-gray-600">Amount Paid Online:</span>
                                  <span className="font-medium text-green-600">₹{parseFloat(bookingDetails.amountPaid).toFixed(2)}</span>
                              </div>
                              {parseFloat(bookingDetails.remainingAmount) > 0 && (
                                <div className="flex justify-between border-t pt-2 mt-2">
                                    <span className="text-gray-600 font-bold">Remaining Amount:</span>
                                    <span className="font-bold text-red-600">₹{parseFloat(bookingDetails.remainingAmount).toFixed(2)}</span>
                                </div>
                              )}
                          </div>
                          <p className="text-xs text-gray-500 mt-2">
                            Mode: {bookingDetails.paymentMode} <br/>
                            ID: {bookingDetails.paymentId}
                          </p>
                      </div>
                  </div>
              </div>
          </div>

          <div className="bg-gray-50 px-6 py-4 border-t border-gray-200">
            <h3 className="font-medium text-gray-900 mb-2">Important Information</h3>
            <ul className="text-sm text-gray-600 space-y-1 list-disc pl-5">
              <li>Please bring your original ID proof and Driving License for verification.</li>
              <li>Inspect the bike thoroughly before starting your trip.</li>
              {parseFloat(bookingDetails.remainingAmount) > 0 && <li>The remaining amount is due at pickup.</li>}
              <li>Late returns may incur additional charges as per our policy.</li>
            </ul>
          </div>
        </div>

        <div className="mt-8 flex flex-col sm:flex-row justify-center gap-4">
          <Link href="/" className="inline-flex items-center justify-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
            Back to Home
          </Link>
          <button onClick={() => window.print()} className="inline-flex items-center justify-center px-6 py-3 border border-gray-300 text-base font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
            <FileText className="mr-2 -ml-1 h-5 w-5"/> Print Confirmation
          </button>
        </div>
      </div>
    </div>
  )
}

export default SuccessPage
