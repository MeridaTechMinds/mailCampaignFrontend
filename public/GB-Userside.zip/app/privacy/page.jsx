// components/PrivacyPolicy.js or pages/privacy-policy.js

import Footer from '@/components/Barcomponents/Footer';
import Navbar from '@/components/Barcomponents/Navbar';
import React from 'react';

const Privacy= () => {
  // Get the current date and format it for display
  const effectiveDate = new Date().toLocaleDateString('en-IN', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  return (
   <div>
    <Navbar />
     <div className="container mx-auto p-4 sm:p-6 lg:p-8 font-sans">
      <h1 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-6 text-center">Privacy Policy</h1>
      <p className="text-gray-600 text-center mb-8">
        Effective Date: {effectiveDate}
      </p>

      <div className="bg-white shadow-lg rounded-lg p-6 sm:p-8">
        <p className="mb-6 text-gray-700 leading-relaxed">
          ADRENALINE RIDERS PVT LTD ("we", "our", "us") is committed to protecting your privacy. This Privacy Policy explains how we collect, use, share, and protect your personal data when you use our website{' '}
          <a href="https://grabbikes.in" className="text-blue-600 hover:underline" target="_blank" rel="noopener noreferrer">https://grabbikes.in</a>{" "}
          ("Platform") or our services. By accessing or using the Platform, you agree to the practices described in this Policy and our Terms of Use.
        </p>

        <Section title="1. Applicability">
          <p>
            This Privacy Policy applies to users located in India. We do not offer services outside India. All data is processed and stored in accordance with Indian laws.
          </p>
        </Section>

        <Section title="2. Information We Collect">
          <h4 className="font-semibold text-gray-800 mt-4 mb-2">a. Personal Data You Provide</h4>
          <p>When you sign up or interact with our services, we may collect:</p>
          <ul className="list-disc list-inside ml-4 mt-2 space-y-1">
            <li>Name</li>
            <li>Date of birth</li>
            <li>Email ID</li>
            <li>Phone number</li>
            <li>Address (billing/shipping)</li>
            <li>Government ID or KYC documents</li>
            <li>Payment data (card, UPI, wallet info)</li>
            <li>Facial or biometric data (for verification, where applicable)</li>
          </ul>
          <h4 className="font-semibold text-gray-800 mt-4 mb-2">b. Information Collected Automatically</h4>
          <p>We may automatically collect:</p>
          <ul className="list-disc list-inside ml-4 mt-2 space-y-1">
            <li>Device information</li>
            <li>IP address</li>
            <li>Browser type</li>
            <li>Location (approximate)</li>
            <li>Usage logs</li>
            <li>Cookies and tracking data</li>
          </ul>
        </Section>

        <Section title="3. How We Use Your Information">
          <p>We use your data to:</p>
          <ul className="list-disc list-inside ml-4 mt-2 space-y-1">
            <li>Register and manage your account</li>
            <li>Process bookings and payments</li>
            <li>Verify identity and prevent fraud</li>
            <li>Respond to queries and customer support</li>
            <li>Send transactional or promotional updates (with opt-out option)</li>
            <li>Conduct analytics and improve services</li>
            <li>Comply with legal obligations</li>
          </ul>
        </Section>

        <Section title="4. Legal Basis for Processing">
          <p>We process your data based on:</p>
          <ul className="list-disc list-inside ml-4 mt-2 space-y-1">
            <li>Your consent</li>
            <li>Performance of a contract</li>
            <li>Legal compliance</li>
            <li>Legitimate interests, such as improving services or fraud prevention</li>
          </ul>
        </Section>

        <Section title="5. Sharing of Information">
          <p>We may share your data with:</p>
          <ul className="list-disc list-inside ml-4 mt-2 space-y-1">
            <li>Internal group companies and affiliates</li>
            <li>Third-party service providers (logistics, payment gateways, KYC vendors)</li>
            <li>Law enforcement or government bodies (as required by law)</li>
            <li>Marketing/analytics providers (with consent or opt-out option)</li>
          </ul>
          <p className="mt-2">
            We ensure these third parties follow strict confidentiality and data protection standards.
          </p>
        </Section>

        <Section title="6. Cookies and Tracking">
          <p>
            We use cookies and similar tracking tools to enhance your Browse experience. You may choose to disable cookies through your browser settings. However, this may affect certain features of the Platform.
          </p>
        </Section>

        <Section title="7. Data Security">
          <p>
            We adopt reasonable technical and organizational measures to protect your data. However, no method of transmission over the Internet is 100% secure.
          </p>
        </Section>

        <Section title="8. Data Retention and Deletion">
          <p>We retain your data for as long as necessary to:</p>
          <ul className="list-disc list-inside ml-4 mt-2 space-y-1">
            <li>Fulfill the purpose for which it was collected</li>
            <li>Comply with legal, tax, and regulatory requirements</li>
          </ul>
          <p className="mt-2">You may request deletion of your account/data by:</p>
          <ul className="list-disc list-inside ml-4 mt-2 space-y-1">
            <li>Visiting account settings, or</li>
            <li>Emailing us at <a href="mailto:support@grabbikes.in" className="text-blue-600 hover:underline">support@grabbikes.in</a></li>
          </ul>
        </Section>

        <Section title="9. Your Rights">
          <p>You have the right to:</p>
          <ul className="list-disc list-inside ml-4 mt-2 space-y-1">
            <li>Access your data</li>
            <li>Correct/update inaccurate data</li>
            <li>Withdraw consent</li>
            <li>Request deletion (subject to applicable laws)</li>
            <li>Object to certain uses (e.g., marketing)</li>
          </ul>
          <p className="mt-2">
            To exercise any of the above rights, please email us at <a href="mailto:support@grabbikes.in" className="text-blue-600 hover:underline">support@grabbikes.in</a>
          </p>
        </Section>

        <Section title="10. Children's Privacy">
          <p>
            Our Platform is not intended for children under the age of 18. We do not knowingly collect data from minors.
          </p>
        </Section>

        <Section title="11. Changes to this Policy">
          <p>
            We may update this Privacy Policy from time to time. The latest version will be posted on the Platform with an updated effective date. Continued use after updates means you accept the revised policy.
          </p>
        </Section>

        <Section title="12. Contact Us">
          <p>If you have questions, concerns, or complaints regarding this Policy or our data practices, contact:</p>
          <p className="mt-2">
            ADRENALINE RIDERS PVT LTD<br />
            Email: <a href="mailto:support@grabbikes.in" className="text-blue-600 hover:underline">support@grabbikes.in</a><br />
            Address: #49, Sugan Complex, pillar no. - 103, CMH road, Halasuru, Bangalore 560008
          </p>
        </Section>
      </div>
    </div>
    <Footer/>
   </div>
  );
};

// Helper component for consistent section styling
const Section = ({ title, children }) => (
  <div className="mb-8">
    <h3 className="text-xl sm:text-2xl font-semibold text-gray-800 mb-4 border-b-2 border-blue-500 pb-2">
      {title}
    </h3>
    <div className="text-gray-700 leading-relaxed">
      {children}
    </div>
  </div>
);

export default Privacy;