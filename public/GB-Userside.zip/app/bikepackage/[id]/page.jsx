"use client";

import Footer from "@/components/Barcomponents/Footer";
import Navbar from "@/components/Barcomponents/Navbar";
import Iframecomp from "@/components/Particularcomponents/Iframe";
import Productsec1 from "@/components/Particularcomponents/Productsec1";
import Productsec2 from "@/components/Particularcomponents/Productsec2";
import Remember from "@/components/Particularcomponents/Remember";
import Reviews from "@/components/Particularcomponents/Reviews";
import { useParams } from "next/navigation";
import { useState, useEffect } from "react";
import axios from "axios";
import Rentalsec4 from "@/components/Rentalcomponents/Rentalsec4";

function Particularbikepackage() {
  const [bike, setBike] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const params = useParams();
  const bikeId = params.id; 

  useEffect(() => {
    const fetchBikePackage = async () => {
      try {
        setLoading(true);
        const res = await axios.get(
          `${process.env.NEXT_PUBLIC_PORT}/bikes/${bikeId}`
        );
        setBike(res.data);
      } catch (error) {
        console.error("Failed to fetch bike package:", error);
        setError("Failed to load bike package");
      } finally {
        setLoading(false);
      }
    };

    if (bikeId) {
      fetchBikePackage();
    }
  }, [bikeId]);

  if (loading) return <div>Loading bike package...</div>;
  if (error) return <div>{error}</div>;
  if (!bike) return <div>Bike package not found</div>;

  return (
    <div>
      <Navbar />
      <Productsec1  />
      <Productsec2 bike={bike} />
      <Remember />
      <Iframecomp bike={bike} />
      <Reviews />
      <Rentalsec4/>
      <Footer />
    </div>
  );
}

export default Particularbikepackage;