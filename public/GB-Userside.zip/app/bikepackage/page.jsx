"use client"

import Footer from "@/components/Barcomponents/Footer"
import Navbar from "@/components/Barcomponents/Navbar"
import Packagesec1 from "@/components/Packagecomponents/Packagesec1"
import Rentalsec4 from "@/components/Rentalcomponents/Rentalsec4"



function Bikepackage(){
    return(
        <div>
           <Navbar/>
            <Packagesec1/>
            <Rentalsec4/>
            <Footer/>
        </div>
    )
}

export default Bikepackage