"use client"

import Footer from "@/components/Barcomponents/Footer"
import Navbar from "@/components/Barcomponents/Navbar"
import Question from "@/components/Barcomponents/Question"
import Listvehsec1 from "@/components/Listvehcomponents/Listvehsec1"
import Listvehsec2 from "@/components/Listvehcomponents/Listvehsec2"
import Listvehsec3 from "@/components/Listvehcomponents/Listvehsec3"
import Listvehsec4 from "@/components/Listvehcomponents/Listvehsec4"
import Rentalsec1 from "@/components/Rentalcomponents/Rentalsec1"




function Listyourvehicle(){
    return(
        <div>
           <Navbar/>
           <Listvehsec1/>
           <Listvehsec2/>
           <Listvehsec3/>
           <Question/>
           <Listvehsec4/>
           <Footer/>
        </div>
    )
}

export default Listyourvehicle