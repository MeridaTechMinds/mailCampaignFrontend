import React from 'react'

const loading = () => {
  return (
    <div>loading

      {/* DATABASES = {                                                                                                                                 
    'default':                                                                                                                                
    {                                                                                                                                         
        'ENGINE': 'django.db.backends.mysql',                                                                                                 
        'NAME': 'bloomindoors',                                                                                                               
        'USER': 'MeridaDatabase',                                                                                                             
        'PASSWORD': 'Team@4321',                                                                                                              
        'HOST': '62.72.59.145',                                                                                                               
        'PORT': '3306',                                                                                                                       
    }                                                                                                                                         
} */}
    </div>
  )
}

export default loading