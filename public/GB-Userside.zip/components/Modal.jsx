
"use client";

import React from 'react';

const Modal = ({ isOpen, onClose, children }) => {
  if (!isOpen) return null;

  return (
    // Backdrop
    <div className="fixed inset-0 bg-black bg-opacity-60 z-50 flex justify-center items-center p-4">
      {/* Modal Container */}
      <div className="bg-white p-5 rounded-lg shadow-2xl max-w-4xl w-full relative">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-2 right-4 text-gray-600 hover:text-black font-bold text-3xl z-10"
          aria-label="Close modal"
        >
          ×
        </button>
        {/* Modal Content */}
        <div className="mt-4 max-h-[85vh] overflow-y-auto">
          {children}
        </div>
      </div>
    </div>
  );
};

export default Modal;