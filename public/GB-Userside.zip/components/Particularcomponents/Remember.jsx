"use client"

import Image from "next/image"



function Remember(){
    return(
       <div className="px-4 py-4">
        <p className="text-xl font-semibold">Things to Remember</p>
         <div className="grid md:grid-cols-5 grid-cols-1 py-6 gap-6  border-b-2">
               <div className=" flex flex-col items-center">
                  <Image src="/tdesign_money-filled.png" width={80} height={30}/>
                  <p className="text-md font-semibold text-center">Flexible Package</p>
                  <p className="text-center">Grab daily,monthly and weekly with affordable rate</p>
               </div>
                 <div className=" flex flex-col items-center">
                  <Image src="/subway_location-2.png" width={80} height={30}/>
                  <p className="text-md font-semibold text-center">Book now & Pay later</p>
                  <p className="text-center">Flexibility to decide when and how to pay</p>
               </div>
                <div className=" flex flex-col items-center">
                  <Image src="/game-icons_path-distance.png" width={80} height={30}/>
                  <p className="text-md font-semibold text-center">Wide Range</p>
                  <p className="text-center">Looking for a locations we have probably got it</p>
               </div>
                <div className=" flex flex-col items-center">
                  <Image src="/mdi_latest.png" width={80} height={30}/>
                  <p className="text-md font-semibold text-center">24*7 service</p>
                  <p className="text-center ">Day or Night rent a bike</p>
               </div>
                <div className=" flex flex-col items-center">
                  <Image src="/fluent_money-hand-20-filled.png" width={80} height={30}/>
                  <p className="text-md font-semibold text-center">License Information</p>
                  <p className="text-center">Processing license details for further steps for riding bike </p>
               </div>
        </div>
       </div>
    )
}

export default Remember