"use client"

import Image from "next/image"
import { useState } from "react"




function Productsec1(){
 const [searchDates, setSearchDates] = useState({
            startDate: '',
            endDate: ''})
 const [location, setLocation] = useState('Bangalore');

    return(
        <div className="px-4 md:px-10 py-4">
                 <div className="bg-[#CCF3FE] p-4 rounded-xl max-w-6xl mx-auto">
                               <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
                                     <div className="relative flex items-center bg-white p-2 rounded-xl">
                                                        
                                                         <input
                                                             type="datetime-local"
                                                             value={searchDates.startDate}
                                                             onChange={(e) => setSearchDates({...searchDates, startDate: e.target.value})}
                                                             className="placeholder-black outline-none w-full pl-10"
                                                         />
                                                          <Image
                                                             src="/calender.png"
                                                             width={20}
                                                             height={20}
                                                             className="absolute left-3 pointer-events-none"
                                                             alt="Calendar icon"
                                                         />
                                                     </div>
                                 <div className="relative bg-white p-2 rounded-xl flex items-center">
                                                      
                                                        <input
                                                            type="datetime-local"
                                                            value={searchDates.endDate}
                                                            onChange={(e) => setSearchDates({...searchDates, endDate: e.target.value})}
                                                            className="placeholder-black outline-none w-full pl-10"
                                                        />
                                                          <Image
                                                            src="/calender.png"
                                                            width={20}
                                                            height={20}
                                                            className="absolute left-3 pointer-events-none"
                                                            alt="Calendar icon"
                                                        />
                                                    </div>
                                    <div className="relative flex bg-white p-2 rounded-xl items-center">
                                                         
                                                          <input
                                                              type="text"
                                                              value={location}
                                                              onChange={(e) => setLocation(e.target.value)}
                                                              placeholder="Enter location"
                                                              className="placeholder-black outline-none w-full"
                                                          />
                                                           <Image
                                                              src="/mdi_location.png"
                                                              width={20}
                                                              height={20}
                                                              className=" left-3 pointer-events-none"
                                                              alt="Location icon"
                                                          />
                                                      </div>
                                   <button 
                                    
                                       className="bg-[#263069] p-2 rounded-xl text-white font-semibold w-full hover:bg-[#1a2350] transition-colors"
                                   >
                                       Search
                                   </button>
                               </div>
                           </div>
        </div>
    )
}

export default Productsec1