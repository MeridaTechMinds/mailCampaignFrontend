"use client"

function Iframecomp({ bike }) {
 
  const extractSrcFromIframe = (iframeString) => {
    if (!iframeString) return '';
    const match = iframeString.match(/src="([^"]*)"/);
    return match ? match[1] : '';
  };

  const iframeSrc = extractSrcFromIframe(bike?.locationIframe || '');

  return (
    <div className="px-3 py-3">
      <p className="text-xl font-semibold">Pickup Location</p>
      <p className="text-[#00B8EF]">{bike?.location || 'Location not specified'}</p>

      {iframeSrc ? (
        <iframe 
          src={iframeSrc}
          width="100%" 
          height="450" 
          style={{ border: 0, borderBottom: "2px solid #000" }} 
          allowFullScreen 
          loading="lazy" 
          referrerPolicy="no-referrer-when-downgrade"
          className="py-4"
        />
      ) : (
        <div className="h-[450px] bg-gray-100 flex items-center justify-center">
          <p>No location map available</p>
        </div>
      )}
    </div>
  );
}

export default Iframecomp;