// Productsec2.js
"use client"

import Image from "next/image"
import { useRouter } from "next/navigation"
import { useEffect, useState } from "react"
import Modal from "../Modal"
import Terms from "@/app/terms/page"


function Productsec2({ bike }) {
  const router = useRouter()
  const [selectedPackage, setSelectedPackage] = useState(null)
  const [currentImageIndex, setCurrentImageIndex] = useState(0)
  const [selectedDuration, setSelectedDuration] = useState('perhour')
  const [calculatedPrice, setCalculatedPrice] = useState(0)
  const [durationUnits, setDurationUnits] = useState(1)
  const [isTermsModalOpen, setIsTermsModalOpen] = useState(false)

  const handlebooking = () => {
    router.push(
      `/payment?` +
      `bikeId=${bike._id}&` +
      `bikeName=${encodeURIComponent(bike.brand + ' ' + bike.name)}&` +
      `bikeImage=${encodeURIComponent(bike.image[0])}&` +
      `durationType=${selectedDuration}&` +
      `units=${durationUnits}&` +
      `baseRentAmount=${selectedPackage?.[selectedDuration] || 0}&` +
      `totalPrice=${calculatedPrice}&` +
      `pickupLocation=${encodeURIComponent(bike.location)}`
    )
  }

  const nextImage = () => {
    setCurrentImageIndex((prevIndex) =>
      prevIndex === bike.image.length - 1 ? 0 : prevIndex + 1
    )
  }

  const prevImage = () => {
    setCurrentImageIndex((prevIndex) =>
      prevIndex === 0 ? bike.image.length - 1 : prevIndex - 1
    )
  }

  useEffect(() => {
    if (bike && bike.price) {
      setSelectedPackage(bike.price)
      setCalculatedPrice(bike.price.perhour)
    }
  }, [bike])

  useEffect(() => {
    if (selectedPackage) {
      const basePrice = selectedPackage[selectedDuration]
      setCalculatedPrice(basePrice * durationUnits)
    }
  }, [selectedDuration, selectedPackage, durationUnits])

  const handleDurationChange = (e) => {
    setSelectedDuration(e.target.value)
    setDurationUnits(1)
  }

  const handleUnitsChange = (e) => {
    const value = parseInt(e.target.value, 10)
    if (!isNaN(value) && value >= 1) {
      setDurationUnits(value)
    } else if (e.target.value === '') {
      setDurationUnits('');
    }
  }

  const incrementUnits = () => {
    setDurationUnits(prevUnits => (typeof prevUnits === 'number' ? prevUnits + 1 : 1))
  }

  const decrementUnits = () => {
    setDurationUnits(prevUnits => (prevUnits > 1 ? prevUnits - 1 : 1))
  }

  if (!bike) return <div>Loading bike details...</div>

  return (
    <>
      <div className="grid md:grid-cols-2 py-4 px-10">
        <div className="border border-[#ACACAC] md:w-[90%] space-y-10 relative">
          {/* Image Carousel */}
          {bike.image && bike.image.length > 0 ? (
            <div className="relative h-80 overflow-hidden">
              <img
                src={bike.image[currentImageIndex]}
                alt={`${bike.brand} ${bike.name}`}
                className="w-full h-full object-contain"
              />

              {/* Image Indicators */}
              <div className="absolute bottom-2 left-0 right-0 flex justify-center gap-2">
                {bike.image.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentImageIndex(index)}
                    className={`w-3 h-3 rounded-full ${currentImageIndex === index ? 'bg-blue-500' : 'bg-gray-300'}`}
                  />
                ))}
              </div>
            </div>
          ) : (
            <div className="w-full h-64 bg-gray-200 flex items-center justify-center">
              <span>No image available</span>
            </div>
          )}

          <div className="flex justify-evenly">
            <div className="flex gap-2 items-center">
              <Image src="/Group 1597880410.png" width={40} height={40} alt="Make year icon" />
              <p className="md:text-xl font-semibold">Make Year: {bike.makeyear}</p>
            </div>
            <div className="flex gap-2 items-center">
              <Image src="/Group 1597880409.png" width={40} height={40} alt="Kms driven icon" />
              <p className="md:text-xl font-semibold">Kms Driven: {bike.kilometers || 'N/A'} kms</p>
            </div>
          </div>
        </div>

        <div>
          <p className="text-xl font-semibold">{bike.brand} {bike.name}</p>

          <div className="space-y-3 py-2">
            <p className="text-xl font-semibold">Select Duration</p>
          <select
  name="duration"
  className="w-[80%] p-2 border border-gray-300 rounded"
  onChange={handleDurationChange}
  value={selectedDuration}
>
  {bike.price?.perhour > 0 && (
    <option value="perhour">Per Hour (₹{bike.price.perhour})</option>
  )}
  {bike.price?.perday > 0 && (
    <option value="perday">Per Day (₹{bike.price.perday})</option>
  )}
  {bike.price?.perweek > 0 && (
    <option value="perweek">Per Week (₹{bike.price.perweek})</option>
  )}
  {bike.price?.permonth > 0 && (
    <option value="permonth">Per Month (₹{bike.price.permonth})</option>
  )}
</select>

          </div>

          <div className="space-y-3 py-2">
            <p className="text-xl font-semibold">Number of {selectedDuration === 'perhour' ? 'Hours' : selectedDuration === 'perday' ? 'Days' : selectedDuration === 'perweek' ? 'Weeks' : 'Months'}</p>
            <div className="flex items-center space-x-2">
              <button onClick={decrementUnits} className="bg-gray-200 text-gray-700 px-3 py-1 rounded-full text-lg font-bold hover:bg-gray-300">-</button>
              <input type="number" min="1" value={durationUnits} onChange={handleUnitsChange} className="w-20 text-center p-2 border border-gray-300 rounded" />
              <button onClick={incrementUnits} className="bg-gray-200 text-gray-700 px-3 py-1 rounded-full text-lg font-bold hover:bg-gray-300">+</button>
            </div>
          </div>

          <p className="py-2 text-md font-semibold">Fare Details</p>
          <div className="flex justify-between py-2 ">
            <p>Rent amount ({selectedDuration === 'perhour' ? 'per hour' : selectedDuration === 'perday' ? 'per day' : selectedDuration === 'perweek' ? 'per week' : 'per month'})</p>
            <p className="font-bold">₹ {selectedPackage?.[selectedDuration] || 'N/A'}</p>
          </div>
          <div className="flex justify-between py-2 ">
            <p>Total Rent ({durationUnits} {selectedDuration === 'perhour' ? 'hour(s)' : selectedDuration === 'perday' ? 'day(s)' : selectedDuration === 'perweek' ? 'week(s)' : 'month(s)'})</p>
            <p className="font-bold">₹ {calculatedPrice}</p>
          </div>
          <div className="flex justify-between py-2">
            <p>Total Payable Amount</p>
            <p className="font-bold">₹ {calculatedPrice}</p>
          </div>

          <button onClick={handlebooking} className="bg-[#263069] text-white text-xl font-bold p-2 w-[80%] rounded cursor-pointer hover:bg-[#1a2350] transition-colors">
            Book Now
          </button>

          <div className="md:space-x-60 space-y-5 py-4">
            {/* THIS BUTTON NOW OPENS THE MODAL */}
            <button className="border-1 p-2 hover:text-blue-600" onClick={() => setIsTermsModalOpen(true)}>
              Terms & Conditions
            </button>
          </div>

          <p className="py-2 text-xl font-semibold">Features</p>
          <div className="grid md:grid-cols-3 gap-5">
            <div className="flex gap-2"><Image src="/Group 1597880414.png" width={40} height={40} alt="Vehicle type icon" /><div><p>Vehicle type</p><p className="font-semibold">{bike.vehicletype || 'N/A'}</p></div></div>
            <div className="flex gap-2"><Image src="/Group 1597880414.png" width={40} height={40} alt="Fuel type icon" /><div><p>Fuel type</p><p className="font-semibold">{bike.fueltype || 'N/A'}</p></div></div>
            {bike.features && bike.features.map((feature, index) => (
              <div key={index} className="flex gap-2"><Image src="/Group 1597880414.png" width={40} height={40} alt="Feature icon" /><div><p>{feature.name}</p><p>{feature.value}</p></div></div>
            ))}
          </div>
        </div>
      </div>

    
      <Modal isOpen={isTermsModalOpen} onClose={() => setIsTermsModalOpen(false)}>
     
        <Terms isModal={true} />
      </Modal>
    </>
  )
}

export default Productsec2;
