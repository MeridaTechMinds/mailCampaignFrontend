"use client"
import { useState } from 'react';

const Reviews = () => {
  const allReviews = [
    {
      id: 1,
      name: 'Arjun Reddy',
      rating: 5,
      date: 'Yesterday',
      bike: 'Activa 6G',
      location: 'Grab Bikes Main Office',
      content: 'Perfect scooter for Bangalore traffic! Rented the Activa 6G for daily office commute from Indiranagar to MG Road. Super smooth ride and great mileage. GrabBikes made the pickup process at their Indiranagar office very convenient.'
    },
    {
      id: 2,
      name: 'Priya Menon',
      rating: 4,
      date: '3 days ago',
      bike: 'Honda Cliq',
      location: 'Grab Bikes Main Office',
      content: 'Good experience with the Honda Cliq. Used it for weekend errands around Koramangala. The automatic transmission was very helpful in Bangalore traffic. Only minor issue was some scratches on the body, but overall good condition.'
    },
    {
      id: 3,
      name: 'Vikram Shetty',
      rating: 5,
      date: '1 week ago',
      bike: 'Dio BS6',
      location: 'Grab Bikes Main Office',
      content: 'Excellent service! The Dio BS6 was perfect for my daily commute from Whitefield to Manyata Tech Park. Fuel efficient and comfortable even in heavy traffic. Will definitely rent from GrabBikes again.'
    },
    {
      id: 4,
      name: 'Ananya Deshpande',
      rating: 4,
      date: '2 weeks ago',
      bike: 'Activa 6G',
      location: 'Grab Bikes Main Office',
      content: 'Great experience overall. The Activa 6G was in perfect condition. Used it for 2 days to explore Bangalore. Pickup and drop at HSR location was smooth. Suggestion: Please add more helmets as options.'
    }
  ];

  const [showAllReviews, setShowAllReviews] = useState(false);
  const displayedReviews = showAllReviews ? allReviews : allReviews.slice(0, 2);

  const ratingDistribution = {
    5: 68,
    4: 25,
    3: 5,
    2: 1,
    1: 1
  };

  const averageRating = 4.5;
  const totalReviews = 217;

  // Circular progress component
  const CircularRating = ({ rating }) => {
    const circumference = 2 * Math.PI * 40;
    const strokeDashoffset = circumference - (rating / 5) * circumference;

    return (
      <div className="relative w-24 h-24">
        <svg className="w-full h-full" viewBox="0 0 100 100">
          <circle
            cx="50"
            cy="50"
            r="40"
            fill="none"
            stroke="#e2e8f0"
            strokeWidth="8"
          />
          <circle
            cx="50"
            cy="50"
            r="40"
            fill="none"
            stroke="#56D601"
            strokeWidth="8"
            strokeDasharray={circumference}
            strokeDashoffset={strokeDashoffset}
            strokeLinecap="round"
            transform="rotate(-90 50 50)"
          />
        </svg>
        <div className="absolute inset-0 flex items-center justify-center">
          <span className="text-2xl font-bold">{rating.toFixed(1)}</span>
        </div>
      </div>
    );
  };

  return (
    <div className="max-w-4xl mx-auto p-6 bg-white rounded-lg shadow-sm">
      <h1 className="text-2xl font-bold mb-6">Customer Reviews</h1>
      
      <div className="flex flex-col md:flex-row gap-8 mb-8">
        {/* Rating Summary */}
        <div className="w-full md:w-1/3 flex flex-col items-center md:items-start">
          <div className="mb-4">
            <CircularRating rating={averageRating} />
          </div>
          <div className="text-2xl font-bold mb-1">{averageRating.toFixed(1)} out of 5</div>
          <div className="text-gray-500 mb-6">{totalReviews} Bangalore reviews</div>
          
          {/* Star Ratings */}
          <div className="space-y-2 w-full">
            {[5, 4, 3, 2, 1].map((stars) => (
              <div key={stars} className="flex items-center">
                <div className="w-10 text-sm">{stars} ★</div>
                <div className="flex-1 h-4 bg-gray-200 rounded mx-2">
                  <div 
                    className="h-full bg-[#56D601] rounded" 
                    style={{ width: `${ratingDistribution[stars]}%` }}
                  ></div>
                </div>
                <div className="w-10 text-sm text-right">
                  {ratingDistribution[stars]}%
                </div>
              </div>
            ))}
          </div>
        </div>
        
        {/* Reviews List */}
        <div className="w-full md:w-2/3">
          
          <div className="space-y-6">
            {displayedReviews.map((review) => (
              <div key={review.id} className="border-b pb-4">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <h3 className="font-medium">{review.name}</h3>
                    <p className="text-gray-500 text-sm">
                      {review.bike} • {review.location} • {review.date}
                    </p>
                  </div>
                  <div className="text-yellow-500">
                    {'★'.repeat(review.rating)}{'☆'.repeat(5 - review.rating)}
                  </div>
                </div>
                <p className="text-gray-600">{review.content}</p>
              </div>
            ))}
          </div>

          <button 
            onClick={() => setShowAllReviews(!showAllReviews)}
            className="mt-6 px-4 py-2 bg-[#56D601] text-white rounded hover:bg-green-600 transition"
          >
            {showAllReviews ? 'Show Less Reviews' : 'See All Reviews'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default Reviews;