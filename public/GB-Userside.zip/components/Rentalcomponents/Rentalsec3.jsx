"use client"

import Image from "next/image"
import discountImg from '../../public/iconamoon_discount-bold.png'
import helmetImg from '../../public/helment.png'


function Rentalsec3() {
    return (
        <div className="relative md:min-h-[80vh]  py-2">
            <p className="text-center text-2xl poppins md:text-4xl font-semibold pt-6">Why rent monthly?</p>
            <div className="grid md:grid-cols-3 grid-cols-1 poppins container mx-auto py-12">
                <div className="mb-4">
                    <div className="flex justify-center md:mb-4">
                        <Image src={discountImg} alt="DiscountImage" width={200} height={100} />
                    </div>
                    <p className="text-center font-semibold mb-4"> Ride Free. Ride Bold. </p>
                    <p className="text-center w-[92%]">
                        Experience true independence with the freedom to ride anytime,
                        anywhere—no schedules, no limits, just you and the open road,
                        ready for every journey that comes your way
                    </p>


                </div>
                <div className="mb-4">

                    <div className="flex justify-center  md:mb-8">
                        <Image src={helmetImg} width={200} height={100} />
                    </div>
                    <p className="text-center font-semibold mb-4"> Helmet Safety First </p>
                    <p className="text-center w-[92%]">
                        Wearing a helmet can be the difference between life and death on the road.
                        It protects your head from serious injuries during accidents, no matter how short the ride or slow the speed.
                        A small habit like strapping on your helmet can save your life and set an example for others. Ride safe,
                        always wear your helmet.
                    </p>
                </div>
                <div>
                    <div className="flex justify-center md:mb-4">
                        <Image src="/picon_shield.png" width={200} height={100} />
                    </div>
                    <p className="text-center font-semibold mb-4">
                        Care for Your Ride. It’ll Care for You.
                    </p>
                    <p className="text-center w-[92%]">
                        Regular maintenance keeps your bike running smooth, safe, and reliable. From checking brakes and oil to inspecting
                        tires and lights, a few minutes
                        of care can prevent big problems later. A well-maintained bike isn’t just efficient — it’s your trusted companion on every road.   </p>

                </div>
            </div>
        </div>
    )
}

export default Rentalsec3