"use client"

import { Archivo } from "next/font/google";
import Image from "next/image";
import personPort from '../../public/monthlyrentalpotrait.png';
import tickimg from '../../public/mdi_tick-circle.png';
import { useRouter } from "next/navigation";
import { useState } from "react"; // 1. Import useState

const archivoBlack = Archivo({
  subsets: ["latin"],
  weight: "400",
});

function Rentalsec1() {
  const router = useRouter();

  // 2. Create state variables to hold input values
  const [location, setLocation] = useState("Bangalore");
  const [date, setDate] = useState("June 17, 2025 10:00 AM");

  const handleSearch = () => {
    // 3. Use the state variables to build the query string
    router.push(`/bikepackage?location=${location}&date=${date}`);
  };

  return (
    <div className="py-6 px-3 container mx-auto relative min-h-[90vh] lg:flex z-20">
      <main className=" flex flex-col justify-around ">
        <h3 className={` !text-3xl md:!text-5xl tracking-wide fw-semibold ${archivoBlack.className}`}>
          Convenient and
          <span className="text-[#00B8EF]"> pocket-friendly</span> and <br /> travel solutions
        </h3>
        <article>
          <section className=" grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 md:gap-20 lg:gap-40 px-5">
            <div className=" w-full">
              <p className="flex md:mb-5 items-center md:w-[180%]">
                <Image src={tickimg} alt="tickImage" width={20} height={20} className="mr-1" />
                Well-Maintained Vehicles
              </p>
              <p className="flex md:w-[180%] items-center "><Image src={tickimg} alt="tickImage" width={20} height={20} className="mr-1" />
                Simple Booking Process
              </p>
            </div>
            <div>
              <p className="flex md:mb-5 md:w-[180%] items-center "><Image src={tickimg} alt="tickImage" width={20} height={20} className="mr-1" />
                Responsive Customer Support
              </p>
              <p className="flex md:w-[180%] items-center "><Image src={tickimg} alt="tickImage" width={20} height={20} className="mr-1" />
                Safety and Assurance
              </p>
            </div>
          </section>

          <section className="backdrop-blur border rounded-[20px] border-gray-400 md:w-[63%] p-3 z-20">
            <p className="text-xl font-semibold">
              Search for the Bike <span className="text-[#00B8EF]"> Near You.. </span>
            </p>
            <div className="my-4 grid gap-2 md:grid-cols-2">
              <div className="relative border flex lg:w-[80%] p-2 rounded-xl items-center">
                <input
                  type="text"
                  placeholder="Bangalore"
                  value={location} // 4. Bind value to state
                  onChange={(e) => setLocation(e.target.value)} // 5. Update state on change
                  className=" placeholder-black border-[#00B8EF] outline-none w-full"
                />
                <Image src="/mdi_location.png" width={20} height={20}
                  className=" pointer-events-none"
                  alt="Location icon"
                />
              </div>
              <div className="relative border flex lg:w-[80%] items-center p-2 rounded-xl">
                <input
                  type="datetime-local"
                  placeholder="June 17, 2025 10:00 AM"
                  value={date} 
                  onChange={(e) => setDate(e.target.value)} 
                  className=" placeholder-black border-[#00B8EF] outline-none w-full"
                />
              </div>
            </div>

            <button className="bg-[#00B8EF] p-2 !rounded-[10px] text-white text-xl ml-3 w-[26%]" onClick={handleSearch}>Search</button>
          </section>
        </article>
      </main>

      <div className="relative lg:absolute lg:right-0 lg:top-1/2 lg:-translate-y-1/2 ">
        <Image src="/Vector 154.png" width={550} height={100} alt="background vector" />
        <Image src={personPort}
          width={450} height={100} className="absolute top-1/2 -translate-y-1/2 right-0 " alt="person on a bike" />
      </div>
    </div>
  )
}

export default Rentalsec1;