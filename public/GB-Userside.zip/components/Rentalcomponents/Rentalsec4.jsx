"use client"

import Image from "next/image"
import { useState } from "react"
import callavatar from '../../public/getInTouchCall.png'
import { ToastContainer, toast } from "react-toastify"
import "react-toastify/dist/ReactToastify.css"
import axios from "axios"

function Rentalsec4() {
    const [formData, setFormData] = useState({ name: "", phone: "" })
    const [error, setError] = useState("")
    const [isLoading, setIsLoading] = useState(false)

    const handleChange = (e) => {
        setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }))
        setError("") 
    }

    const handleSubmit = async () => {
        const { name, phone } = formData
        if (!name.trim() || !phone.trim()) {
            setError("Please fill out both fields.")
            return
        }
        
        if (!/^\d{10}$/.test(phone)) {
            setError("Please enter a valid 10-digit mobile number")
            return
        }

        try {
            setIsLoading(true)
            await axios.post(`${process.env.NEXT_PUBLIC_PORT}/call`, formData)
            toast.success("✅ Your request has been submitted!")
            setFormData({ name: "", phone: "" })
        } catch (err) {
            console.error("Error submitting:", err)
            toast.error(err.response?.data?.message || "❌ Something went wrong.")
        } finally {
            setIsLoading(false)
        }
    }

    return (
        <div className="bg-[#32C5F2] w-[95%] mx-auto rounded-lg px-4 py-6 mb-4 mt-10 relative h-auto 
                        md:w-[90%] md:px-8 md:py-4 md:mt-16 md:min-h-[35vh]
                        lg:w-[88%] lg:ml-10 lg:px-10 lg:py-2 lg:min-h-[40vh] lg:mt-20">

            <p className="text-2xl font-semibold poppins
                        md:!text-3xl md:text-left">
                Get a call back</p>
            <p className="text-xl mt-2 poppins
                        md:text-base ">
                We're here to help every step of the way.</p>

            {error && (
                <p className="text-red-700 text-sm mt-2 md:text-left">{error}</p>
            )}

            <div className="flex flex-col sm:gap-0 gap-3 py-5 w-full items-center z-20
                            md:flex-row md:w-[70%] md:absolute md:top-20 md:left-8 md:items-start
                            lg:w-[50%] lg:top-24 lg:left-16 lg:py-15">
                <input 
                    type="text" 
                    name="name"
                    placeholder="Name" 
                    value={formData.name}
                    onChange={handleChange}
                    className="bg-white p-3 w-[90%] rounded-md outline-none
                                md:w-1/3 lg:w-[80%]" 
                    disabled={isLoading}
                />
                <input 
                    type="tel" 
                    name="phone"
                    placeholder="Mobile Number" 
                    value={formData.phone}
                    onChange={handleChange}
                    className="bg-white p-3 w-[90%] rounded-md outline-none
                                md:w-1/3 lg:w-[80%]" 
                    maxLength="10"
                    disabled={isLoading}
                />
                <button 
                    onClick={handleSubmit}
                    disabled={isLoading}
                    className={`text-white p-3 w-[90%] font-semibold rounded-md
                                md:w-1/3 lg:w-[40%] 
                                ${isLoading ? 'bg-gray-500 cursor-not-allowed' : 'bg-black hover:bg-gray-800'}`}>
                    {isLoading ? 'Submitting...' : 'Submit'}
                </button>
            </div>

            <div className="d-none d-lg-block absolute right-0 h-full bottom-0" >
                <Image
                    src="/litebluediv.png"
                    width={460}
                    height={100}
                    alt="Decorative light blue shape"
                    className="h-full w-full"
                />
                <Image 
                    src={callavatar} 
                    width={300} 
                    height={100}
                    alt="Customer support representative"
                    className="absolute bottom-0 right-0" 
                />
            </div>

            <ToastContainer 
                position="top-center" 
                autoClose={3000} 
                hideProgressBar={false}
                newestOnTop={false}
                closeOnClick
                rtl={false}
                pauseOnFocusLoss
                draggable
                pauseOnHover
                theme="light"
            />
        </div>
    )
}

export default Rentalsec4