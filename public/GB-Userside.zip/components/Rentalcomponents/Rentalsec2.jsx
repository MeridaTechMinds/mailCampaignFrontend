"use client"
import Image from "next/image"
import selectBike from '../../public/selectbike.png'
import howitworks from '../../public/HowItWorks.png'



function Rentalsec2() {
    return (
        <div className="bg-[#F7F7F7] flex flex-col relative h-auto min-h-[90vh] py-12 md:py-10 px-4">
            {/* Title */}
            <p className="text-center text-3xl md:!text-5xl font-semibold mb-12">
                How it works?</p>

            {/* Vector line - made responsive */}
            {/* <div className=" w-full h-1 mb-16 md:mb-24 md:block hidden">
                <Image
                    src="/Vector 156.png"
                    fill
                    className="object-contain"
                    alt="Decorative line"
                />
            </div> */}

            {/* Steps container */}
            <Image src={howitworks} alt="How-it" width={1000} height={300}
                className=" w-full my-auto" />
            {/* <main className="relative w-full bg-red-300 container mx-auto">

                <div className="grid grid-cols-1 md:grid-cols-5 gap-10 md:gap-[15%]">
                   
                    <div className="flex flex-col min-h-[10vh] bg-red-400 items-center text-center">
                        <div className="relative md:w-40 w-20 bg-red-700 mb-8 ">
                            <Image
                                src={selectBike}
                                width={250}
                                height={100}
                                className=""
                            />
                        </div>
                        <p className="font-semibold text-lg md:text-xl">
                            Select the bike
                        </p>
                    </div>

                  
                    <div className="flex flex-col items-center text-center ">
                        <div className="relative w-20 md:w-44 mb-4">
                            <Image
                                src="/ChatGPT Image Jun 18, 2025, 06_33_31 PM 1.png"
                                width={150}
                                height={100}
                                className=""
                                alt="Payment"
                            />
                        </div>
                        <p className="font-semibold text-lg md:text-xl">
                            Book and pay for the first month
                        </p>
                    </div>

                    <div className="flex flex-col items-center text-center ">
                        <div className="relative w-20  md:w-44  mb-7">
                            <Image
                                src="/workimg1.png"
                                width={350}
                                height={100}
                                className=""
                                alt="Bike delivery"
                            />
                        </div>
                        <p className="font-semibold text-lg md:text-xl">
                            Get the bike delivered to your doorstep
                        </p>
                    </div>

                    <div className="flex flex-col items-center text-center md:ml-5">
                        <div className="relative w-20  md:w-40  mb-7">
                            <Image
                                src="/workimg2.png"
                                width={150}
                                height={100}
                                className=""
                                alt="Monthly payment"
                            />
                        </div>
                        <p className="font-semibold text-lg md:text-xl">
                            Pay for upcoming months at the start of every month
                        </p>
                    </div>

                    <div className="flex flex-col items-center text-center md:ml-10">
                        <div className="relative w-20 md:w-40  mb-7">
                            <Image
                                src="/workimg3.png"
                                width={150}
                                height={100}
                                className=""
                                alt="Bike service"
                            />
                        </div>
                        <p className="font-semibold text-lg md:text-xl ">
                            We will service the bike once every month
                        </p>
                    </div>
                </div>
            </main> */}
        </div>
    )
}

export default Rentalsec2