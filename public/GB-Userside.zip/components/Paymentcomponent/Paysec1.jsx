"use client";
import { useSearchParams } from "next/navigation";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Image from "next/image";
import axios from "axios";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import Modal from "../Modal";
import Terms from "@/app/terms/page";

function Paysec1() {
  const searchParams = useSearchParams();
  const router = useRouter();

  // State variables
  const [bikeId, setBikeId] = useState("");
  const [bikeName, setBikeName] = useState("");
  const [bikeImage, setBikeImage] = useState("");
  const [baseRentAmount, setBaseRentAmount] = useState(0);
  const [calculatedTotalRent, setCalculatedTotalRent] = useState(0);
  const [gstAmount, setGstAmount] = useState(0);
  const GST_PERCENTAGE = 28;
  const [durationType, setDurationType] = useState("");
  const [durationUnits, setDurationUnits] = useState(0);
  const [pickupDateTime, setPickupDateTime] = useState("");
  const [endDateTime, setEndDateTime] = useState("");
  const [pickupLocation, setPickupLocation] = useState(
    decodeURIComponent(searchParams.get("pickupLocation") || "Jayanagar 4th block")
  );
  const [termsAccepted, setTermsAccepted] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [paymentMode, setPaymentMode] = useState("online");
  const [paymentOption, setPaymentOption] = useState("full");
  const [error, setError] = useState(null);
  const [isTermsModalOpen, setIsTermsModalOpen] = useState(false);
  const [isCashDisabled, setIsCashDisabled] = useState(true);
  const [isCheckingAuth, setIsCheckingAuth] = useState(true);
  const [estimatedKm, setEstimatedKm] = useState(0);
  const [extraKmCharge, setExtraKmCharge] = useState(0);
  const [kmLimit, setKmLimit] = useState(0);

  // Accessories State
  const [selectedAccessories, setSelectedAccessories] = useState([]);
  const availableAccessories = [
    { name: "Helmet", pricePerDay: 50, description: "Premium safety helmet" },
    { name: "Phone Holder", pricePerDay: 50, description: "Secure phone mount" },
  ];

  const RAZORPAY_KEY_ID = process.env.NEXT_PUBLIC_RAZORPAY_KEY_ID;
  const CASH_ON_PICKUP_ADVANCE_PERCENTAGE = 20;
  const EXTRA_KM_RATE = 4; 
  const DEFAULT_KM_LIMIT = {
    perhour: 10,
    perday: 120,
    perweek: 120, 
    permonth: 120, 
  };

  const roundToNearestRupee = (amount) => {
    return Math.round(amount); 
  };

  const calculateRentalDays = () => {
    if (!pickupDateTime || !endDateTime) return 0;
    const diffTime = Math.abs(new Date(endDateTime) - new Date(pickupDateTime));
    return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  };

  // Calculate total accessory price
  const calculateAccessoryTotal = () => {
    if (durationType === "perhour") {
      return Math.min(selectedAccessories.length * 50, 400);
    } else {
      let days;

      if (durationType === "perweek") {
        days = durationUnits * 7;
      } else if (durationType === "permonth") {
        days = durationUnits * 30;
      } else {
        days = durationUnits; 
      }

      const uncappedTotal = selectedAccessories.reduce(
        (sum, accessory) => sum + (accessory.pricePerDay * days),
        0
      );

      return Math.min(uncappedTotal, 400);
    }
  };

  // Calculate km limit based on duration
const calculateKmLimit = () => {
  if (!durationType) return 0;

  // Hourly rental - fixed km limits
  if (durationType === "perhour") {
    if (durationUnits <= 5) return 40;          
    else if (durationUnits <= 10) return 70;    // 6-10 hours = 70 km
    else return 120;                            // 11+ hours = 120 km
  } 

  else {
    return 120 * durationUnits; 
  }
};
  // Calculate extra km charge
  const calculateExtraKmCharge = () => {
    if (estimatedKm <= kmLimit) return 0;
    return (estimatedKm - kmLimit) * EXTRA_KM_RATE;
  };

  // Update total calculation
  useEffect(() => {
    const kmLimitValue = calculateKmLimit();
    setKmLimit(kmLimitValue);
    
    const extraKmChargeValue = calculateExtraKmCharge();
    setExtraKmCharge(extraKmChargeValue);
    
    const accessoryTotal = calculateAccessoryTotal();
    const subtotal = baseRentAmount + accessoryTotal + extraKmChargeValue;
    // Calculate GST only on base rent amount
    const calculatedGst = baseRentAmount * (GST_PERCENTAGE / 100);
    
    // Round GST and subtotal before adding
    const roundedGst = roundToNearestRupee(calculatedGst);
    const roundedSubtotal = roundToNearestRupee(subtotal);
    
    setGstAmount(roundedGst);
    setCalculatedTotalRent(roundedSubtotal + roundedGst);
  }, [baseRentAmount, selectedAccessories, pickupDateTime, endDateTime, estimatedKm, durationType, durationUnits]);

  useEffect(() => {
    const checkAuth = () => {
      const userId = sessionStorage.getItem("userId");
      if (!userId) {
        const bookingDetails = {
          bikeId: searchParams.get("bikeId") || "",
          bikeName: decodeURIComponent(searchParams.get("bikeName") || ""),
          bikeImage: decodeURIComponent(searchParams.get("bikeImage") || ""),
          durationType: searchParams.get("durationType") || "",
          durationUnits: parseInt(searchParams.get("units") || "1"),
          baseRentAmount: parseFloat(searchParams.get("baseRentAmount") || "0"),
          calculatedTotalRent: parseFloat(searchParams.get("totalPrice") || "0"),
          pickupLocation: decodeURIComponent(searchParams.get("pickupLocation") || "Jayanagar 4th block"),
          paymentMode: "online", 
          paymentOption: "full", 
          selectedAccessories: [],
          estimatedKm: 0,
        };
        sessionStorage.setItem('pendingBooking', JSON.stringify(bookingDetails));
        
        router.push(`/login?returnUrl=${encodeURIComponent(window.location.pathname + window.location.search)}`);
      } else {
        const pendingBooking = sessionStorage.getItem('pendingBooking');
        if (pendingBooking) {
          const {
            bikeId: pendingBikeId,
            bikeName: pendingBikeName,
            bikeImage: pendingBikeImage,
            baseRentAmount: pendingBaseRentAmount,
            calculatedTotalRent: pendingCalculatedTotalRent,
            durationType: pendingDurationType,
            durationUnits: pendingDurationUnits,
            pickupLocation: pendingPickupLocation,
            paymentMode: pendingPaymentMode,
            paymentOption: pendingPaymentOption,
            pickupDateTime: pendingPickupDateTime,
            endDateTime: pendingEndDateTime,
            selectedAccessories: pendingAccessories,
            estimatedKm: pendingEstimatedKm
          } = JSON.parse(pendingBooking);

          setBikeId(pendingBikeId);
          setBikeName(pendingBikeName);
          setBikeImage(pendingBikeImage);
          setBaseRentAmount(pendingBaseRentAmount);
          setCalculatedTotalRent(pendingCalculatedTotalRent);
          setDurationType(pendingDurationType);
          setDurationUnits(pendingDurationUnits);
          setPickupLocation(pendingPickupLocation);
          setPaymentMode(pendingPaymentMode);
          setPaymentOption(pendingPaymentOption);
          setPickupDateTime(pendingPickupDateTime);
          setEndDateTime(pendingEndDateTime);
          setSelectedAccessories(pendingAccessories || []);
          setEstimatedKm(pendingEstimatedKm || 0);

          sessionStorage.removeItem('pendingBooking');
        }
        setIsCheckingAuth(false);
      }
    };

    checkAuth();
  }, [router, searchParams]);

  useEffect(() => {
    if (isCheckingAuth) return;

    const pendingBooking = sessionStorage.getItem('pendingBooking');
    if (!pendingBooking) {
      setBikeId(searchParams.get("bikeId") || "");
      setBikeName(decodeURIComponent(searchParams.get("bikeName") || ""));
      setBikeImage(decodeURIComponent(searchParams.get("bikeImage") || ""));
      setDurationType(searchParams.get("durationType") || "");
      setDurationUnits(parseInt(searchParams.get("units") || "1"));
      const basePriceFromUrl = parseFloat(searchParams.get("totalPrice") || "0");
      setBaseRentAmount(basePriceFromUrl);
      setPickupLocation(decodeURIComponent(searchParams.get("pickupLocation") || "Jayanagar 4th block"));
    }
  }, [searchParams, isCheckingAuth]);

  useEffect(() => {
    setIsCashDisabled(calculatedTotalRent <= 100);

    if (calculatedTotalRent <= 100 && paymentMode === "cash") {
      setPaymentMode("online");
      setPaymentOption("full");
    }
    if (paymentMode === "online" && calculatedTotalRent <= 2000) {
      setPaymentOption("full");
    }
  }, [calculatedTotalRent, paymentMode]);

  const calculatePaymentAmount = () => {
    if (paymentMode === "online") {
      if (calculatedTotalRent > 2000 && paymentOption === "partial") {
        return Math.round(calculatedTotalRent / 2);
      }
      return calculatedTotalRent;
    } else if (paymentMode === "cash") {
      if (!isCashDisabled) {
        return Math.round(calculatedTotalRent * (CASH_ON_PICKUP_ADVANCE_PERCENTAGE / 100));
      }
    }
    return 0;
  };

  const calculateRemainingAmount = () => {
    if (paymentMode === "online" && paymentOption === "partial") {
      return calculatedTotalRent - Math.round(calculatedTotalRent / 2);
    } else if (paymentMode === "cash" && !isCashDisabled) {
      return calculatedTotalRent - Math.round(calculatedTotalRent * (CASH_ON_PICKUP_ADVANCE_PERCENTAGE / 100));
    }
    return 0;
  };

  const calculateEndDateTime = (start) => {
    if (!start || !durationType || !durationUnits) return;
    const end = new Date(start);
    switch (durationType) {
      case "perhour":
        end.setHours(end.getHours() + durationUnits);
        break;
      case "perday":
        end.setDate(end.getDate() + durationUnits);
        break;
      case "perweek":
        end.setDate(end.getDate() + durationUnits * 7);
        break;
      case "permonth":
        end.setMonth(end.getMonth() + durationUnits);
        break;
      default:
        break;
    }
    setEndDateTime(end.toISOString());
  };

  useEffect(() => {
    if (pickupDateTime) calculateEndDateTime(pickupDateTime);
  }, [pickupDateTime, durationType, durationUnits]);

  const loadRazorpay = async () => {
    return new Promise((resolve) => {
      if (window.Razorpay) return resolve(true);
      const script = document.createElement("script");
      script.src = "https://checkout.razorpay.com/v1/checkout.js";
      script.onload = () => resolve(true);
      script.onerror = () => resolve(false);
      document.body.appendChild(script);
    });
  };

  const getDurationText = (t) =>
    ({
      perhour: "Hour(s)",
      perday: "Day(s)",
      perweek: "Week(s)",
      permonth: "Month(s)",
    }[t] || "");

  const handleDateTimeChange = (e) => {
    setPickupDateTime(e.target.value);
  };

  const handleKmChange = (e) => {
    setEstimatedKm(parseInt(e.target.value) || 0);
  };

  const completeBooking = async (paymentId, amountPaidOnline) => {
    try {
      const userId = sessionStorage.getItem("userId");
      if (!userId) {
        toast.error("User session expired. Please login again.");
        const bookingDetails = {
          bikeId,
          bikeName,
          bikeImage,
          baseRentAmount,
          calculatedTotalRent,
          durationType,
          durationUnits,
          pickupLocation,
          paymentMode,
          paymentOption,
          pickupDateTime,
          endDateTime,
          selectedAccessories,
          estimatedKm
        };
        sessionStorage.setItem('pendingBooking', JSON.stringify(bookingDetails));
        router.push(`/login?returnUrl=${encodeURIComponent(window.location.pathname + window.location.search)}`);
        return;
      }

      let bookingStatus = "confirmed";
      let remainingAmount = 0;

      if (paymentMode === "online" && calculatedTotalRent > 2000 && paymentOption === "partial") {
        bookingStatus = "partially_paid";
        remainingAmount = calculatedTotalRent - amountPaidOnline;
      } else if (paymentMode === "cash" && !isCashDisabled) {
        bookingStatus = "partially_paid";
        remainingAmount = calculatedTotalRent - amountPaidOnline;
      } else if (paymentMode === "online" && paymentOption === "full") {
        bookingStatus = "confirmed";
        remainingAmount = 0;
      }

      const { data } = await axios.post(`${process.env.NEXT_PUBLIC_PORT}/booking`, {
        user: userId,
        Bike: bikeId,
        startDate: new Date(pickupDateTime).toISOString(),
        endDate: new Date(endDateTime).toISOString(),
        pickuplocation: pickupLocation,
        returnlocation: pickupLocation,
        totalprice: calculatedTotalRent,
        amountPaid: amountPaidOnline,
        paymentMode,
        paymentId: paymentId || null,
        status: bookingStatus,
        remainingAmount: remainingAmount,
        accessories: selectedAccessories,
        kmLimit: kmLimit,
        estimatedKm: estimatedKm,
        extraKmCharge: extraKmCharge
      });

      sessionStorage.removeItem('pendingBooking');

      let successMsg = "";
      if (paymentMode === "online" && paymentOption === "full") {
        successMsg = "Payment & booking confirmed!";
      } else if (paymentMode === "online" && paymentOption === "partial") {
        successMsg = `Partial payment received! Pay remaining ₹${remainingAmount} later.`;
      } else if (paymentMode === "cash") {
        successMsg = `Advance payment received for Cash on Pickup! Pay remaining ₹${remainingAmount} at pickup.`;
      }

      toast.success(successMsg);

      router.push(
        `/payment/success?bookingId=${data.booking.bookingId}` +
        `&bikeName=${encodeURIComponent(bikeName)}` +
        `&amountPaidOnline=${amountPaidOnline}` +
        `&paymentId=${paymentId || "Advance for Cash"}` +
        `&paymentMode=${paymentMode}` +
        `&pickupDate=${encodeURIComponent(pickupDateTime)}` +
        `&returnDate=${encodeURIComponent(endDateTime)}` +
        `&pickupLocation=${encodeURIComponent(pickupLocation)}` +
        (remainingAmount > 0 ? `&remainingAmount=${remainingAmount}` : "") +
        `&totalPriceWithGST=${calculatedTotalRent}` +
        `&kmLimit=${kmLimit}` +
        `&estimatedKm=${estimatedKm}` +
        `&extraKmCharge=${extraKmCharge}`
      );

    } catch (err) {
      toast.error("Failed to complete booking");
      throw err;
    }
  };

  const processPayment = async (amountToPay) => {
    try {
      const userId = sessionStorage.getItem("userId");
      const userData = JSON.parse(sessionStorage.getItem("userData") || "{}");

      const scriptLoaded = await loadRazorpay();
      if (!scriptLoaded) {
        toast.error("Failed to load Razorpay. Try again.");
        return;
      }

      const { data: orderRes } = await axios.post(
        `${process.env.NEXT_PUBLIC_PORT}/create-razorpay-order`,
        {
          amount: amountToPay,
          bikeId,
          userId,
          bookingDetails: {
            bikeName,
            pickupDateTime,
            endDateTime,
            pickupLocation,
            isPartial: paymentOption === "partial" || paymentMode === "cash",
            accessories: selectedAccessories,
            kmLimit,
            estimatedKm,
            extraKmCharge
          },
        }
      );

      const order = orderRes.order;

      const options = {
        key: RAZORPAY_KEY_ID,
        amount: order.amount,
        currency: "INR",
        name: "Grabbikes",
        description: `Booking for ${bikeName}`,
        image: "/GrabBikesLogo.png",
        order_id: order.id,
        handler: async (response) => {
          try {
            const { razorpay_payment_id, razorpay_order_id, razorpay_signature } = response;
            if (!razorpay_payment_id || !razorpay_order_id || !razorpay_signature) {
              throw new Error("Incomplete payment response");
            }

            const { data: verifyRes } = await axios.post(`${process.env.NEXT_PUBLIC_PORT}/verify-payment`, {
              razorpay_payment_id,
              razorpay_order_id,
              razorpay_signature,
              amount: amountToPay,
              bikeId,
              userId,
              bookingDetails: {
                bikeName,
                pickupDateTime,
                endDateTime,
                pickupLocation,
                isPartial: paymentOption === "partial" || paymentMode === "cash",
                accessories: selectedAccessories,
                kmLimit,
                estimatedKm,
                extraKmCharge
              },
            });

            await completeBooking(verifyRes.paymentId, amountToPay);

          } catch (err) {
            console.error("Verification Error:", err);
            toast.error("Payment verification failed. Contact support.");
            setIsLoading(false);
          }
        },
        prefill: {
          name: userData.name,
          email: userData.email,
          contact: userData.phone,
        },
        theme: { color: "#00B8EF" },
        modal: {
          ondismiss: () => {
            toast.info("Payment cancelled.");
            setIsLoading(false);
          },
        },
      };

      const rzp = new window.Razorpay(options);
      rzp.open();
    } catch (err) {
      console.error("Payment Error:", err);
      toast.error(err.response?.data?.message || "Payment failed");
      throw err;
    }
  };

  const handlerPayNow = async () => {
    setError(null);
    if (!termsAccepted) return toast.error("Please accept terms.");
    if (!pickupDateTime) return toast.error("Select pickup time.");

    setIsLoading(true);

    const timeout = setTimeout(() => {
      if (isLoading) {
        toast.warning("Payment taking too long...");
        setIsLoading(false);
      }
    }, 30000);

    try {
      const { data: chk } = await axios.post(`${process.env.NEXT_PUBLIC_PORT}/booking/check`, {
        bikeId,
        startDate: new Date(pickupDateTime),
        endDate: new Date(endDateTime),
      });

      if (chk.isBooked) {
        setError("Bike already booked.");
        toast.error("Bike unavailable. Try different dates.");
        return;
      }

      const amountToPay = calculatePaymentAmount();

      if (amountToPay <= 0 && paymentMode !== 'cash') {
        toast.error("Payment amount cannot be zero.");
        return;
      }

      await processPayment(amountToPay);

    } catch (err) {
      setError(err.message);
    } finally {
      clearTimeout(timeout);
      setIsLoading(false);
    }
  };

  if (isCheckingAuth) {
    return (
      <div className="flex justify-center items-center h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  return (
    <div className="px-12 py-2 h-auto">
      <ToastContainer position="top-right" autoClose={5000} />
      <p className="text-xl font-semibold">Summary</p>
      <div className="grid md:grid-cols-2 gap-10">
        <div className="border border-[#9E9E9E] p-4 space-y-4">
          {bikeImage && (
            <div className="relative w-[200px] h-[100px]">
              <img
                src={bikeImage}
                alt={bikeName}
                className="object-contain w-full h-full"
              />
            </div>
          )}
          <div className="px-10 py-5">
            <p className="text-lg font-semibold">{bikeName}</p>
            <p>Rent: ₹{baseRentAmount.toFixed(2)} / {getDurationText(durationType)}</p>
            <p>Duration: {durationUnits} {getDurationText(durationType)}</p>
          </div>
          <div>
            <p className="text-[#00B8EF] text-xl font-semibold">Pickup Location:</p>
            <div className="flex gap-4 items-center">
              <Image
                src="/Group 1597880409.png"
                width={40}
                height={40}
                alt="location"
              />
              <p>{pickupLocation}</p>
            </div>
          </div>
          <div className="space-y-3">
            <p className="text-[#00B8EF] text-xl font-semibold">Pickup Date & Time:</p>
            <input
              type="datetime-local"
              value={pickupDateTime}
              onChange={handleDateTimeChange}
              className="mt-1 block w-full p-2 border rounded focus:ring-blue-500"
              required
              min={new Date().toISOString().slice(0, 16)}
            />
          </div>
          {endDateTime && (
            <div className="space-y-3">
              <p className="text-[#00B8EF] text-xl font-semibold">Return Date & Time:</p>
              <div className="p-2 bg-gray-100 rounded">
                {new Date(endDateTime).toLocaleString('en-IN')}
              </div>
            </div>
          )}
          
          {/* KM Limit and Estimated KM Section */}
         <div className="space-y-3">
  <p className="text-[#00B8EF] text-xl font-semibold">KM Details:</p>
  <div className="p-2 bg-gray-100 rounded">
    {durationType === "perhour" ? (
      <>
        <p>KM Limit: {kmLimit} km (Fixed limit)</p>
        <p className="text-sm mt-1">
          {durationUnits <= 5 && "1-5 hours: 40 km"}
          {durationUnits > 5 && durationUnits <= 10 && "6-10 hours: 70 km"}
          {durationUnits > 10 && "11+ hours: 120 km"}
        </p>
      </>
    ) : (
      <p>KM Limit: {kmLimit} km ({durationUnits} {getDurationText(durationType)} × 120 km)</p>
    )}
    <div className="mt-2">
      <label className="block text-sm font-medium text-gray-700">
        Estimated KM (Extra km charged at ₹4/km)
      </label>
    </div>
  </div>
</div>
        </div>

        <div>
          <div className="border border-[#9E9E9E] px-4 py-4 mb-4">
            <p className="text-xl font-semibold">Fare Details</p>
            
            {/* Accessories Selection */}
            <div className="mt-4 border-b pb-4">
              <p className="font-semibold mb-2">
                Add Accessories: 
                {durationType === "perhour" 
                  ? "₹50 per item (fixed)" 
                  : "₹50/day per item"}
              </p>
              <div className="space-y-3">
                {availableAccessories.map((accessory) => (
                  <label
                    key={accessory.name}
                    className="flex items-start justify-between p-2 hover:bg-gray-50 rounded cursor-pointer"
                  >
                    <div className="flex items-center">
                      <input
                        type="checkbox"
                        checked={selectedAccessories.some((a) => a.name === accessory.name)}
                        onChange={() => {
                          if (selectedAccessories.some((a) => a.name === accessory.name)) {
                            setSelectedAccessories(
                              selectedAccessories.filter((a) => a.name !== accessory.name)
                            );
                          } else {
                            setSelectedAccessories([...selectedAccessories, accessory]);
                          }
                        }}
                        className="form-checkbox h-5 w-5 text-blue-600 rounded focus:ring-blue-500"
                      />
                      <div className="ml-3">
                        <p className="font-medium">{accessory.name}</p>
                        <p className="text-sm text-gray-500">{accessory.description}</p>
                      </div>
                    </div>
                    <span className="font-medium">₹{accessory.pricePerDay}/day</span>
                  </label>
                ))}
              </div>
            </div>

            {/* Base Rent */}
            <div className="flex justify-between border-b mt-5 pb-2">
              <p>Base Rent ({durationUnits} {getDurationText(durationType)}):</p>
              <p>₹{baseRentAmount.toFixed(2)}</p>
            </div>

            {/* KM Limit and Extra KM Charge */}
            <div className="flex justify-between border-b mt-2 pb-2">
              <p>KM Limit ({kmLimit} km):</p>
              <p>Included</p>
            </div>
            
            {extraKmCharge > 0 && (
              <div className="flex justify-between border-b mt-2 pb-2">
                <p>Extra KM Charge ({estimatedKm - kmLimit} km × ₹{EXTRA_KM_RATE}):</p>
                <p>₹{extraKmCharge.toFixed(2)}</p>
              </div>
            )}

            <div className="flex justify-between border-b mt-2 pb-2">
              <p>GST ({GST_PERCENTAGE}% on baserent):</p>
              <p>₹{gstAmount}</p>
            </div>

            {/* Selected Accessories */}
            {selectedAccessories.length > 0 && (
              <div className="border-b py-2">
                <p className="font-medium mb-1">Accessories (Max ₹400):</p>
                {selectedAccessories.map((accessory) => {
                  let priceInfo = "";
                  let totalPrice = 0;

                  if (durationType === "perhour") {
                    priceInfo = "Fixed ₹50 per item";
                    totalPrice = 50;
                  } else {
                    const days = 
                      durationType === "perweek" ? durationUnits * 7 :
                      durationType === "permonth" ? durationUnits * 30 :
                      durationUnits;

                    totalPrice = accessory.pricePerDay * days;
                    priceInfo = `₹${accessory.pricePerDay}/day × ${days} days`;
                  }

                  return (
                    <div key={accessory.name} className="flex justify-between text-sm">
                      <span className="ml-4">
                        + {accessory.name} ({priceInfo})
                      </span>
                      <span>₹{Math.min(totalPrice, 400).toFixed(2)}</span>
                    </div>
                  );
                })}
                {calculateAccessoryTotal() >= 400 && (
                  <p className="text-sm text-orange-500 mt-1">
                    Note: Total accessories capped at ₹400
                  </p>
                )}
              </div>
            )}

            <div className="flex justify-between border-b mt-2 pb-2">
              <p className="font-medium">Subtotal:</p>
              <p>₹{roundToNearestRupee(baseRentAmount + calculateAccessoryTotal() + extraKmCharge)}</p>
            </div>

            {/* Total Payable */}
            <div className="flex justify-between pt-2">
              <p className="font-semibold">Total Rent:</p>
              <p className="font-bold">₹{calculatedTotalRent}</p>
            </div>
          </div>

          <label className="flex items-center px-2 py-6">
            <input
              type="checkbox"
              checked={termsAccepted}
              onChange={e => setTermsAccepted(e.target.checked)}
              className="form-checkbox"
            />
            <span className="ml-2">
              I have read the <button className="text-blue-600 hover:underline" onClick={() => setIsTermsModalOpen(true)}>
                terms & conditions
              </button>
            </span>
          </label>

          <div className="border border-[#9E9E9E] px-4 py-4 mb-4">
            <p className="text-xl font-semibold mb-3">Choose Payment Mode</p>
            <label className="flex items-center space-x-2">
              <input
                type="radio"
                value="online"
                name="payment"
                checked={paymentMode === 'online'}
                onChange={() => setPaymentMode('online')}
                className="form-radio mr-2"
              />
              <span>Online Payment (Full or 50% Advance)</span>
            </label> <br />
            <label className={`flex items-center space-x-2 mt-2 ${isCashDisabled ? 'opacity-50 cursor-not-allowed' : ''}`}>
              <input
                type="radio"
                value="cash"
                name="payment"
                checked={paymentMode === 'cash'}
                onChange={() => !isCashDisabled && setPaymentMode('cash')}
                className="form-radio"
                disabled={isCashDisabled}
              />
              <span>Cash on Pickup {isCashDisabled && "(Available only for amounts over ₹100)"}</span>
            </label>
            
            {paymentMode === "online" && calculatedTotalRent > 2000 && (
              <div className="mt-4 pl-6 border-t pt-3">
                <p className="font-medium mb-2">Payment Option:</p>
                <label className="flex items-center space-x-2">
                  <input
                    type="radio"
                    value="full"
                    name="paymentOption"
                    checked={paymentOption === 'full'}
                    onChange={() => setPaymentOption('full')}
                    className="form-radio"
                  />
                  <span>Pay Full Amount (₹{calculatedTotalRent.toFixed(2)})</span>
                </label>
                <label className="flex items-center space-x-2 mt-2">
                  <input
                    type="radio"
                    value="partial"
                    name="paymentOption"
                    checked={paymentOption === 'partial'}
                    onChange={() => setPaymentOption('partial')}
                    className="form-radio"
                  />
                  <span>Pay 50% Now (₹{Math.round(calculatedTotalRent / 2).toFixed(2)})</span>
                </label>
              </div>
            )}
            
            {paymentMode === "cash" && !isCashDisabled && (
              <p className="text-sm text-orange-500 mt-2">
                Note: A {CASH_ON_PICKUP_ADVANCE_PERCENTAGE}% advance is required online. Pay remaining ₹{calculateRemainingAmount().toFixed(2)} in cash during pickup.
              </p>
            )}
            {paymentMode === "online" && calculatedTotalRent > 2000 && (
              <p className="text-sm text-orange-500 mt-2">
                Note: For amounts over ₹2000, you can choose to pay 50% now and the rest later.
              </p>
            )}
          </div>

          {error && (
            <div className="text-red-500 mb-4 p-2 bg-red-50 rounded">
              {error}
            </div>
          )}

          <button
            onClick={handlerPayNow}
            disabled={!termsAccepted || !pickupDateTime || isLoading}
            className={`bg-[#00B8EF] text-white text-xl font-bold p-3 rounded w-[50%]
              ${(!termsAccepted || !pickupDateTime || isLoading) ? 'opacity-50 cursor-not-allowed' : 'hover:bg-[#0095D9]'}`}
          >
            {isLoading ? (
              <span className="flex items-center justify-center">
                <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Processing...
              </span>
            ) : (
              paymentMode === 'online'
                ? (paymentOption === 'partial' ? `PAY ₹${Math.round(calculatedTotalRent / 2).toFixed(2)} (50%)` : `PAY ₹${calculatedTotalRent.toFixed(2)}`)
                : `PAY ₹${calculatePaymentAmount().toFixed(2)} (ADVANCE FOR CASH)`
            )}
          </button>
        </div>
      </div>
      <Modal isOpen={isTermsModalOpen} onClose={() => setIsTermsModalOpen(false)}>
        <Terms isModal={true} />
      </Modal>
    </div>
  );
}

export default Paysec1;





