"use client"

import Image from "next/image"

function Listvehsec4(){
    return(
        <div className="bg-[#F7F7F7] px-4 py-6 grid md:grid-cols-2 grid-cols-1 md:h-[70vh] h-auto gap-6 relative">
            {/* Content section */}
            <div className="order-2 md:order-1">
                <p className="text-xl md:text-2xl font-semibold mb-4">List your vehicle</p>
                <div className="backdrop-blur w-full md:w-[80%] lg:w-[50%] p-6 md:p-10 border border-gray-400 md:absolute md:left-52 md:top-20 shadow-lg md:shadow-2xl">
                    <p className="text-sm md:text-base">
                        Lorem ipsum dolor sit amet consectetur. Sit enim tincidunt sed facilisis. Pharetra consectetur est metus imperdiet at interdum egestas sit. Mauris consectetur amet aliquet tortor nulla vel massa porttitor dictum. Suspendisse amet sit id rutrum. Sed amet semper duis amet sapien id diam praesent. Facilisis amet ipsum mattis vestibulum ullamcorper curabitur ipsum massa aliquet. Vitae auctor eget eros elementum natoque arcu felis. Pulvinar integer mauris proin vivamus molestie posuere. Enim nunc sem ac egestas mauris feugiat. In tortor est nec augue in egestas. Leo cursus consequat rhoncus faucibus mi quam in. Arcu lectus sem quis. 
                    </p>
                    <button className="border border-[#00B8EF] text-[#00B8EF] rounded p-2 mt-4 w-full md:w-auto md:ml-52">
                        Start Earning With Bikes
                    </button>
                </div>
            </div>
            
            {/* Image section */}
            <div className="order-1 md:order-2 flex justify-center">
                <Image 
                    src="/electricscooter.png" 
                    width={450} 
                    height={300}
                    className="w-[300px] md:w-[450px]"
                    alt="Electric scooter"
                />
            </div>
        </div>
    )
}

export default Listvehsec4