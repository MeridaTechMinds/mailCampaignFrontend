"use client"

import Image from "next/image"


function Listvehsec3(){
    return(
          <div className="relative md:h-[80vh]  py-2">
                     <p className="text-center text-xl md:text-2xl font-semibold pt-6">Why list your bike on bikes?</p>
                     <div className="grid md:grid-cols-4 grid-cols-1 py-14">
                             <div className="mb-4">
                                  <div className="flex justify-center md:mb-4">
                                   <Image src="/streamline-ultimate_cash-payment-bill-bold.png" width={200} height={100}/>
                                  </div>
                                  <p className="text-center font-semibold mb-4">Lorem ipsum dolor sit</p>
                                  <p className="text-center w-[92%]">Lorem ipsum dolor sit amet consectetur. Scelerisque sed nisl viverra amet lectus. Ut mattis ultrices sit varius id ullamcorper.</p>
       
                    
                             </div>
                             <div className="mb-4">
       
                                 <div className="flex justify-center  md:mb-4">
                                   <Image src="/fluent_money-off-24-filled.png" width={200} height={100}/>
                                  </div>
                                 <p className="text-center font-semibold mb-4">Lorem ipsum dolor sit</p>
                                  <p className="text-center w-[92%]">Lorem ipsum dolor sit amet consectetur. Scelerisque sed nisl viverra amet lectus. Ut mattis ultrices sit varius id ullamcorper.</p>
                             </div>
                             <div>
                                  <div className="flex justify-center md:mb-4">
                                     <Image src="/bx_support.png" width={200} height={100}/>
                                  </div>
                                  <p className="text-center font-semibold mb-4">Lorem ipsum dolor sit</p>
                                  <p className="text-center w-[92%]">Lorem ipsum dolor sit amet consectetur. Scelerisque sed nisl viverra amet lectus. Ut mattis ultrices sit varius id ullamcorper.</p>
       
                             </div>
                              <div>
                                  <div className="flex justify-center md:mb-4">
                                   <Image src="/ri_e-bike-fill.png" width={200} height={100}/>
                                  </div>
                                  <p className="text-center font-semibold mb-4">Lorem ipsum dolor sit</p>
                                  <p className="text-center w-[92%]">Lorem ipsum dolor sit amet consectetur. Scelerisque sed nisl viverra amet lectus. Ut mattis ultrices sit varius id ullamcorper.</p>
       
                             </div>
                     </div>
               </div>
    )
}

export default Listvehsec3