"use client"

import Image from "next/image"

function Listvehsec2(){
    return(
        <div className="grid md:grid-cols-2 grid-cols-1 md:h-[95vh] h-auto">
            {/* Image section - will be full width on mobile */}
            <div className="md:block flex justify-center">
                <Image 
                    src="/iphoneimg.png" 
                    width={450} 
                    height={100} 
                    className="md:w-[450px] w-[300px]"
                    alt="Phone illustration"
                />
            </div>
            
            {/* Content section */}
            <div className="md:px-10 px-4 md:py-12 py-6">
                <p className="text-xl font-extrabold mb-4">Process</p>
                <div className="space-y-4">
                    {/* Step 1 */}
                    <div className="bg-[#AEEDFFB5] md:w-[90%] w-full p-3 flex gap-3 rounded-xl">
                        <Image 
                            src="/profileimgbikes.png" 
                            width={60} 
                            height={60}
                            className="w-12 h-12 md:w-15 md:h-15"
                            alt="Step icon"
                        />
                        <div>
                            <p className="text-md font-bold">Step 1:</p>
                            <p className="text-sm md:text-base">Lorem ipsum dolor sit amet consectetur. Vitae a lorem aliquam dignissim tristique in duis.</p>
                        </div>
                    </div>
                    
                    {/* Step 2 */}
                    <div className="bg-[#AEEDFFB5] md:w-[90%] w-full p-3 flex gap-3 rounded-xl">
                        <Image 
                            src="/profileimgbikes.png" 
                            width={60} 
                            height={60}
                            className="w-12 h-12 md:w-15 md:h-15"
                            alt="Step icon"
                        />
                        <div>
                            <p className="text-md font-bold">Step 2:</p>
                            <p className="text-sm md:text-base">Lorem ipsum dolor sit amet consectetur. Vitae a lorem aliquam dignissim tristique in duis.</p>
                        </div>
                    </div>
                    
                    {/* Step 3 */}
                    <div className="bg-[#AEEDFFB5] md:w-[90%] w-full p-3 flex gap-3 rounded-xl">
                        <Image 
                            src="/profileimgbikes.png" 
                            width={60} 
                            height={60}
                            className="w-12 h-12 md:w-15 md:h-15"
                            alt="Step icon"
                        />
                        <div>
                            <p className="text-md font-bold">Step 3:</p>
                            <p className="text-sm md:text-base">Lorem ipsum dolor sit amet consectetur. Vitae a lorem aliquam dignissim tristique in duis.</p>
                        </div>
                    </div>
                    
                    {/* Step 4 */}
                    <div className="bg-[#AEEDFFB5] md:w-[90%] w-full p-3 flex gap-3 rounded-xl">
                        <Image 
                            src="/profileimgbikes.png" 
                            width={60} 
                            height={60}
                            className="w-12 h-12 md:w-15 md:h-15"
                            alt="Step icon"
                        />
                        <div>
                            <p className="text-md font-bold">Step 4:</p>
                            <p className="text-sm md:text-base">Lorem ipsum dolor sit amet consectetur. Vitae a lorem aliquam dignissim tristique in duis.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Listvehsec2