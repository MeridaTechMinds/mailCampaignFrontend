"use client"

import { Archivo } from "next/font/google";
import Image from "next/image";

const archivoBlack = Archivo({
  subsets: ["latin"],
  weight: "400",
});

function Listvehsec1() {
    return (
        <div className="md:py-10 px-10 relative md:h-[100vh] h-[140vh]  flex z-20">
            <div>
                <h3 className={`text-3xl font-semibold md:w-[40%] ${archivoBlack.className}`}>
                    Did you know you can now make <span className="text-[#00B8EF]"> money</span> out of your unused <span className="text-[#00B8EF]"> two-wheeler</span>?
                </h3>
                <div className="bg-[#00B8EF] md:w-[40%] text-white font-semibold p-2 mt-5">
                    <p>Lorem ipsum dolor sit amet sit</p> 
                </div>
                <p className="text-md font-semibold py-10 md:block hidden">
                    Lorem ipsum dolor sit amet consectetur. <br /> 
                    Mattis euismod ac consectetur cursus aliquam quisque turpis. <br /> 
                    Ultricies ullamcorper nullam id vel ultrices. <br /> 
                    Adipiscing fames diam blandit mattis nullam quis. <br /> 
                    Non aliquet consequat nulla ut quis. <br /> 
                    Dignissim risus imperdiet elit porttitor senectus. <br /> 
                    Nec egestas rhoncus nec leo.
                </p>
                
                {/* Mobile-only paragraph (hidden on desktop) */}
                <p className="text-sm font-semibold py-6 md:hidden block">
                    Lorem ipsum dolor sit amet consectetur. 
                    Mattis euismod ac consectetur cursus aliquam quisque turpis. 
                    Ultricies ullamcorper nullam id vel ultrices. 
                    Adipiscing fames diam blandit mattis nullam quis. 
                    Non aliquet consequat nulla ut quis. 
                    Dignissim risus imperdiet elit porttitor senectus. 
                    Nec egestas rhoncus nec leo.
                </p>
            </div>
            
            {/* Desktop images (unchanged) */}
            <div className="absolute md:top-28 md:left-[50%] top-[79%]">
                <Image src="/listvehhome.png" width={550} height={100} alt="Vehicle" className="w-56 md:w-auto"/>
                <Image src="/ChatGPT Image Jun 19, 2025, 11_26_29 AM 1.png" width={350} height={100} className="absolute md:-top-24 -top-36 md:left-20" alt="ChatGPT" />
            </div>
            
        </div>
    )
}

export default Listvehsec1