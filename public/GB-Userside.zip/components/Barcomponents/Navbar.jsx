"use client";

import Image from "next/image";
import { Belleza } from "next/font/google";
import { useState, useEffect, useRef } from "react";
import { FaBars, FaTimes, FaUserCircle, FaSignOutAlt, FaUser } from "react-icons/fa";
import Link from "next/link";
import { useRouter } from "next/navigation";

const belleza = Belleza({
  subsets: ["latin"],
  weight: "400",
});

const ProfileDropdown = ({ userName, isLanding, onClose }) => {
  const router = useRouter();

  const handleProfileClick = () => {
    router.push('/profile');
    onClose();
  };

  const handleLogout = () => {
    sessionStorage.clear();
    router.push('/');
    onClose();
  };

  return (
    <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-50 border border-gray-200">
      <button
        onClick={handleProfileClick}
        className="flex items-center w-full text-left px-4 py-2 text-black hover:bg-gray-100"
      >
        <FaUser className="mr-2" />
        Profile
      </button>
      <button
        onClick={handleLogout}
        className="flex items-center w-full text-left px-4 py-2 text-black hover:bg-gray-100"
      >
        <FaSignOutAlt className="mr-2" />
        Logout
      </button>
    </div>
  );
};

function Navbar({ isLanding = false }) {
  const [isOpen, setIsOpen] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userName, setUserName] = useState("");
  const [showDropdown, setShowDropdown] = useState(false);
  const dropdownRef = useRef(null);

  useEffect(() => {
    const loggedIn = sessionStorage.getItem("isLoggedIn") === "true";
    const name = sessionStorage.getItem("userName") || "";
    setIsLoggedIn(loggedIn);
    setUserName(name);
  }, []);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setShowDropdown(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const toggleDropdown = () => setShowDropdown(!showDropdown);
  const closeAll = () => {
    setIsOpen(false);
    setShowDropdown(false);
  };

  const navLinks = [
    { href: "/", text: "Home" },
    { href: "/monthly-rentals", text: "Monthly Rentals" },
    { href: "/bikepackage", text: "Bikes" },
  ];

  return (
    <>
      <div className={`flex justify-between items-center w-full p-4 ${
        isLanding ? 'absolute top-0 left-0' : 'bg-white shadow-lg sticky top-0'
      } z-50`}>
        <Link href="/">
          <Image
            src="/GrabBikesLogo.png"
            alt="Bike Logo"
            width={100}
            height={100}
            className={`w-16 ${isLanding ? 'md:w-20 lg:w-24' : ''}`}
          />
        </Link>

        <div className={`hidden md:flex gap-6 lg:gap-10 text-gray-800 text-[16px] lg:text-[20px] ${belleza.className} items-center`}>
          {!isLanding && (
            <a href="tel:+919148855444" className="text-black text-decoration-none flex items-center cursor-pointer">
              <Image src="/phonesymbol.png" width={20} height={20} alt="Phone" />
              +91 9148855444
            </a>
          )}
          
          {navLinks.map((link) => (
            <Link 
              key={link.href}
              href={link.href}
              className="cursor-pointer transition text-decoration-none !text-slate-900 hover:!text-blue-600"
              onClick={closeAll}
            >
              {link.text}
            </Link>
          ))}

          {!isLoggedIn ? (
            <Link 
              href="/login" 
              className="cursor-pointer transition text-decoration-none !text-slate-900 hover:!text-blue-600"
              onClick={closeAll}
            >
              Login
            </Link>
          ) : (
            <div className="relative" ref={dropdownRef}>
              <button
                className="flex items-center gap-2 cursor-pointer hover:text-blue-600"
                onClick={toggleDropdown}
              >
                <FaUserCircle className={`text-2xl ${isLanding ? "text-[#00B8EF]" : "text-[#00B8EF]"}`} />
                <span className="hidden md:inline">{userName}</span>
              </button>
              {showDropdown && <ProfileDropdown userName={userName} isLanding={isLanding} onClose={closeAll} />}
            </div>
          )}
        </div>

        <button
          className="md:hidden text-gray-800 focus:outline-none z-50"
          onClick={() => setIsOpen(!isOpen)}
        >
          {isOpen ? <FaTimes size={24} /> : <FaBars size={24} />}
        </button>
      </div>

      {/* Mobile Menu */}
      <div className={`fixed inset-0 bg-white z-40 transform ${
        isOpen ? 'translate-x-0' : '-translate-x-full'
      } transition-transform duration-300 ease-in-out md:hidden`}>
        <div className="flex flex-col items-center justify-center h-full gap-8 text-xl">
          {!isLanding && (
            <a href="tel:+919148855444" className="flex items-center gap-2">
              <Image src="/phonesymbol.png" width={30} height={30} alt="Phone" />
              +91 9148855444
            </a>
          )}
          
          {navLinks.map((link) => (
            <Link 
              key={link.href}
              href={link.href}
              className="cursor-pointer transition text-decoration-none !text-slate-900 hover:!text-blue-600"
              onClick={closeAll}
            >
              {link.text}
            </Link>
          ))}

          {!isLoggedIn ? (
            <Link 
              href="/login" 
              className="cursor-pointer transition text-decoration-none !text-slate-900 hover:!text-blue-600"
              onClick={closeAll}
            >
              Login
            </Link>
          ) : (
            <div className="flex flex-col items-center gap-2">
              <div className="flex items-center gap-2">
                <FaUserCircle className="text-2xl text-[#00B8EF]" />
                <span>{userName}</span>
              </div>
              <div className="flex gap-4 mt-2">
                <Link 
                  href="/profile" 
                  className="flex items-center px-4 py-2 bg-blue-100 rounded-md"
                  onClick={closeAll}
                >
                  <FaUser className="mr-2" />
                  Profile
                </Link>
                <button
                  onClick={() => {
                    sessionStorage.clear();
                    closeAll();
                    window.location.href = '/';
                  }}
                  className="flex items-center px-4 py-2 bg-red-100 rounded-md"
                >
                  <FaSignOutAlt className="mr-2" />
                  Logout
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </>
  );
}

export default Navbar;