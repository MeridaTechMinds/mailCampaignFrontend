"use client"

import Image from "next/image"
import { useState } from "react"

function Question() {
    const [activeIndex, setActiveIndex] = useState(null)

    const toggleAnswer = (index) => {
        setActiveIndex(activeIndex === index ? null : index)
    }

    const faqs = [
        {
            question: "What documents do I need to rent a bike?",
            answer: "You'll typically need a valid driver's license, proof of identity (like a passport), and a credit card for the security deposit. Some rentals may also require an international driving permit for foreign tourists."
        },
        {
            question: "What is the minimum age requirement for renting a bike?",
            answer: "The minimum age is usually 18 years, but for certain high-powered bikes, you may need to be 21 or older with a valid motorcycle license."
        },
        {
            question: "Are helmets provided with the bike rental?",
            answer: "Yes, we provide DOT-approved helmets free of charge with every rental. We strongly recommend wearing them at all times while riding."
        },
        {
            question: "What happens if the bike gets damaged during my rental?",
            answer: "Our bikes come with basic insurance coverage. You'll be responsible for the deductible amount in case of damage. We recommend purchasing additional coverage for more protection."
        },
        {
            question: "Can I take the bike to another city or state?",
            answer: "Most rentals allow interstate travel, but you should inform us in advance. Some restrictions may apply based on the bike model and rental duration."
        }
    ]

    return (
        <div className="bg-[#F7F7F7] p-4 md:p-6">
            <p className="text-xl md:text-2xl font-semibold mb-4 md:mb-6">Have Questions?</p>

            <div className="space-y-4">
                {faqs.map((faq, index) => (
                    <div key={index} className="pb-3 border-b">
                        <div 
                            className="flex justify-between items-center cursor-pointer"
                            onClick={() => toggleAnswer(index)}
                        >
                            <p className="text-base md:text-xl">{faq.question}</p>
                            <Image 
                                src="/Group 47661.png" 
                                width={24} 
                                height={24} 
                                className={`w-6 h-6 md:w-7 md:h-7 transition-transform duration-200 ${activeIndex === index ? 'transform rotate-180' : ''}`}
                                alt={activeIndex === index ? "Hide answer" : "Show answer"}
                            />         
                        </div>
                        {activeIndex === index && (
                            <div className="mt-3 text-gray-600 animate-fadeIn">
                                {faq.answer}
                            </div>
                        )}
                    </div>
                ))}
            </div>
        </div>
    )
}

export default Question