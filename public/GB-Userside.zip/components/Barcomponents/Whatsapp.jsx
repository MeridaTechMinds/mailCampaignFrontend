import whatsapp from '../../public/whatsapp.png'
import Image from 'next/image'
import Link from 'next/link'

function Whatsapp() {
    return (
        <div className='fixed bottom-5 right-5 z-20 hover:scale-110 transition-transform duration-200'>
            <Link href="https://wa.me/+919148855444" target="_blank" rel="noopener noreferrer">
                <Image 
                    src={whatsapp} 
                    width={60} 
                    height={60} 
                    alt="Chat with us on WhatsApp"
                    className="cursor-pointer"
                />
            </Link>
        </div>
    )
}

export default Whatsapp