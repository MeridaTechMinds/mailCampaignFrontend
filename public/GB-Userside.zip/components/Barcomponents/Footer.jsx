"use client"

import Image from "next/image"
import { useRouter } from "next/navigation"

function Footer() {
    const router = useRouter()
    return (
        <div className="bg-[#263069] text-white p-8">
            <div className="grid grid-cols-1 md:grid-cols-5 gap-8 max-w-6xl mx-auto">
                {/* First Column - Logo */}
                <div>
                    <Image
                        src="/GrabBikesLogo.png"
                        width={200}
                        height={200}
                        className="w-32"
                        alt="Bike Rental Logo"
                    />
                </div>

                {/* Second Column */}
                <div className="space-y-3">
                    {/* <p className="text-lg font-semibold">Contact us</p> */}
                    <p className="text-lg font-semibold cursor-pointer" onClick={() => router.push('/privacy')}>Privacy Policy</p>
                    <p className="text-lg font-semibold cursor-pointer" onClick={() => router.push('/terms')}>Terms and Conditions</p>
                </div>

                {/* Third Column */}
                <div className="space-y-3">
                    <p className="text-lg font-semibold cursor-pointer" onClick={() => router.push('/offer')}>Offers (available soon)</p>
                    <p className="text-lg font-semibold cursor-pointer" onClick={() => router.push('/monthly-rentals')}> Monthly Rental </p>
                    {/* <p className="text-lg font-semibold" onClick={()=>} >FAQs</p> */}
                    <p className="text-lg font-semibold cursor-pointer" onClick={() => router.push('/bikepackage')}> Bikes </p>

                </div>

                {/* Fourth Column */}
                <div className="space-y-2">
                    <p className="text-lg font-semibold ">About us</p>
                    <div className="flex flex-col">
                        <a href="mailto:support@grabbikes.in" className=" text-white text-decoration-none my-2" > support@grabbikes.in</a>
                        <a href="telto:+91 9148855444" className=" text-white text-decoration-none my-2">+91 9148855444</a>
                    </div>
                </div>
                <div className="flex justify-center md:justify-end gap-8 mt-8 md:mt-4">
                    <a href="https://www.instagram.com/grabbikes.in?igsh=bHN5ZHljYnA2Znkw"
                        target="_blank" >
                        <Image
                            src="/skill-icons_instagram.png"
                            width={30}
                            height={30}
                            alt="Instagram"
                            className="w-8 h-8"
                        />
                    </a>
                    <a href="https://www.facebook.com/profile.php?id=61575095427129" target="_blank">
                        <Image
                            src="/logos_facebook.png"
                            width={30}
                            height={30}
                            alt="Facebook"
                            className="w-8 h-8"
                        />
                    </a>
                    {/* <Image
                        src="/Vector.png"
                        width={30}
                        height={30}
                        alt="Twitter"
                        className="w-8 h-8"
                    /> */}
                </div>
            </div>



        </div>
    )
}

export default Footer