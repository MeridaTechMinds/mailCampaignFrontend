"use client";

import Image from "next/image";
import FilterMenu from "./Filtermenu";
import { useState, useEffect, useCallback } from 'react';
import { useRouter, useSearchParams } from "next/navigation";
import axios from "axios";

function Packagesec1() {
    const [selectedFilters, setSelectedFilters] = useState({
        bookingDuration: '',
        transmissiontype: '',
        fueltype: '',
        vehicletype: '',
    });
    const [searchDates, setSearchDates] = useState({
        startDate: '',
        endDate: ''
    });
    const [location, setLocation] = useState('Bangalore');
    const router = useRouter();
    const searchParams = useSearchParams();
    const [bikes, setBikes] = useState([]);
    const [bookings, setBookings] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    const fetchBikes = useCallback(async () => {
        try {
            setLoading(true);
            setError(null);

            const queryParams = new URLSearchParams();

            if (selectedFilters.transmissiontype) {
                queryParams.append('transmissiontype', selectedFilters.transmissiontype);
            }
            if (selectedFilters.fueltype) {
                queryParams.append('fueltype', selectedFilters.fueltype);
            }
            if (selectedFilters.vehicletype) {
                queryParams.append('vehicletype', selectedFilters.vehicletype);
            }

            if (searchDates.startDate) {
                queryParams.append('startDate', searchDates.startDate);
            }
            if (searchDates.endDate) {
                queryParams.append('endDate', searchDates.endDate);
            }

            if (location) {
                queryParams.append('location', location);
            }

            // Fetch bikes
            const bikesResponse = await axios.get(`${process.env.NEXT_PUBLIC_PORT}/bikes?${queryParams.toString()}`);
            
            // Fetch bookings to check availability
            const bookingsResponse = await axios.get(`${process.env.NEXT_PUBLIC_PORT}/bookinginformation`);
            
            setBikes(bikesResponse.data);
            setBookings(bookingsResponse.data);

        } catch (err) {
            setError(err.message);
            console.error('Error fetching data:', err);
        } finally {
            setLoading(false);
        }
    }, [selectedFilters, searchDates, location]);

    // Check if a bike is booked for the selected dates
    const isBikeBooked = (bikeId) => {
        if (!searchDates.startDate || !searchDates.endDate) return false;
        
        const startDate = new Date(searchDates.startDate);
        const endDate = new Date(searchDates.endDate);
        
        return bookings.some(booking => {
            if (booking.Bike?._id !== bikeId) return false;
            
            const bookingStart = new Date(booking.startDate);
            const bookingEnd = new Date(booking.endDate);
            
            // Check for date overlap
            return (
                (startDate >= bookingStart && startDate <= bookingEnd) ||
                (endDate >= bookingStart && endDate <= bookingEnd) ||
                (startDate <= bookingStart && endDate >= bookingEnd)
            );
        });
    };

    useEffect(() => {
        fetchBikes();

        const intervalId = setInterval(() => {
            console.log("Refreshing bike data...");
            fetchBikes();
        }, 30000); // 30 seconds

        const handleFocus = () => {
            console.log("Window focused, refetching bike data...");
            fetchBikes();
        };

        window.addEventListener('focus', handleFocus);

        return () => {
            clearInterval(intervalId);
            window.removeEventListener('focus', handleFocus);
        };
    }, [fetchBikes]);

    const handleSearch = () => {
        fetchBikes();
    };

    const finalFilteredBikes = bikes.filter(bike => {
        // Apply filters
        if (selectedFilters.bookingDuration &&
            bike.duration?.toLowerCase() !== selectedFilters.bookingDuration.toLowerCase()) {
            return false;
        }

        if (selectedFilters.transmissiontype &&
            bike.transmissiontype?.toLowerCase() !== selectedFilters.transmissiontype.toLowerCase()) {
            return false;
        }

        if (selectedFilters.fueltype &&
            bike.fueltype?.toLowerCase() !== selectedFilters.fueltype.toLowerCase()) {
            return false;
        }

        if (selectedFilters.vehicletype &&
            bike.vehicletype?.toLowerCase() !== selectedFilters.vehicletype.toLowerCase()) {
            return false;
        }

        return true;
    });

    const handleView = (bikeId) => {
        // Pass the search dates as query parameters
        const queryParams = new URLSearchParams();
        if (searchDates.startDate) queryParams.append('startDate', searchDates.startDate);
        if (searchDates.endDate) queryParams.append('endDate', searchDates.endDate);
        if (location) queryParams.append('location', location);
        
        router.push(`/bikepackage/${bikeId}?${queryParams.toString()}`);
    };

    const getStatusBadge = (bike) => {
        if (isBikeBooked(bike._id)) {
            return <span className="availability-badge booked">Booked</span>;
        }
        
        switch (bike.availabilitystatus) {
            case 'available':
                return <span className="availability-badge available">Available</span>;
            case 'sold_out':
                return <span className="availability-badge repair">sold_out</span>; 
            case 'pending_payment':
                return <span className="availability-badge pending">Pending Payment</span>;
            default:
                return <span className="availability-badge">Unknown</span>;
        }
    };

    if (loading) {
        return (
            <div className="flex justify-center items-center h-64">
                <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
            </div>
        );
    }

    if (error) {
        return (
            <div className="text-center py-10 text-red-500">
                Error loading bikes: {error}
            </div>
        );
    }

    return (
        <div className="px-4 md:px-10 py-4 space-y-8 relative min-h-screen">
            {/* Search Bar */}
            <div className="bg-[#CCF3FE] p-4 rounded-xl max-w-6xl mx-auto">
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
                    <div className="relative flex items-center bg-white p-2 rounded-xl">
                        <input
                            type="datetime-local"
                            value={searchDates.startDate}
                            onChange={(e) => setSearchDates({...searchDates, startDate: e.target.value})}
                            className="placeholder-black outline-none w-full pl-10"
                        />
                        <Image
                            src="/calender.png"
                            width={20}
                            height={20}
                            className="absolute left-3 pointer-events-none"
                            alt="Calendar icon"
                        />
                    </div>
                    <div className="relative bg-white p-2 rounded-xl flex items-center">
                        <input
                            type="datetime-local"
                            value={searchDates.endDate}
                            onChange={(e) => setSearchDates({...searchDates, endDate: e.target.value})}
                            className="placeholder-black outline-none w-full pl-10"
                        />
                        <Image
                            src="/calender.png"
                            width={20}
                            height={20}
                            className="absolute left-3 pointer-events-none"
                            alt="Calendar icon"
                        />
                    </div>
                    <div className="relative flex bg-white p-2 rounded-xl items-center">
                        <input
                            type="text"
                            value={location}
                            onChange={(e) => setLocation(e.target.value)}
                            placeholder="Enter location"
                            className="placeholder-black outline-none w-full"
                        />
                        <Image
                            src="/mdi_location.png"
                            width={20}
                            height={20}
                            className="left-3 pointer-events-none"
                            alt="Location icon"
                        />
                    </div>
                    <button 
                        onClick={handleSearch}
                        className="bg-[#263069] p-2 !rounded-[10px] text-white font-semibold w-full hover:bg-[#1a2350] transition-colors"
                    >
                        Search
                    </button>
                </div>
            </div>

            {/* Contents */}
            <div className="flex flex-col lg:flex-row gap-6 max-w-6xl mx-auto">
                {/* Filter components */}
                <div className="lg:w-1/4">
                    <FilterMenu selectedFilters={selectedFilters} onFilterChange={setSelectedFilters} />
                </div>

                {/* Bike Display Components */}
                <div className="flex-1">
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5 p-2">
                        {finalFilteredBikes.length > 0 ? (
                            finalFilteredBikes.map((bike) => {
                                const isBooked = isBikeBooked(bike._id);
                                const isAvailable = !isBooked && bike.availabilitystatus === 'available';
                                
                                return (
                                    <div
                                        key={bike._id}
                                        className="border border-gray-200 rounded-xl p-4 shadow-sm hover:shadow-lg transition-all duration-200 bg-white flex flex-col h-full relative"
                                    >
                                        {getStatusBadge(bike)}

                                        <div className="w-full h-48 mb-4 rounded-lg overflow-hidden bg-gray-100 flex items-center justify-center">
                                            {bike.image?.[0] ? (
                                                <img
                                                    src={bike.image[0]}
                                                    alt={`${bike.brand} ${bike.name}`}
                                                    width={200}
                                                    height={150}
                                                    className="object-contain h-full"
                                                    priority
                                                />
                                            ) : (
                                                <div className="text-gray-400">No image available</div>
                                            )}
                                        </div>

                                        <div className="flex-grow">
                                            <div className="flex justify-between items-start mb-2">
                                                <h2 className="text-xl font-bold text-gray-900">{bike.brand} {bike.name}</h2>
                                                <span className="bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded-full">
                                                    {bike.vehicletype}
                                                </span>
                                            </div>

                                            <div className="flex flex-wrap gap-2 mb-3">
                                                <span className="bg-gray-100 px-2 py-1 rounded-full text-xs font-medium">
                                                    {bike.transmissiontype}
                                                </span>
                                                <span className="bg-gray-100 px-2 py-1 rounded-full text-xs font-medium">
                                                    {bike.seats || 2} Seater
                                                </span>
                                                <span className="bg-gray-100 px-2 py-1 rounded-full text-xs font-medium">
                                                    {bike.fueltype}
                                                </span>
                                                <span className="bg-gray-100 px-2 py-1 rounded-full text-xs font-medium">
                                                    Year: {bike.makeyear}
                                                </span>
                                            </div>

                                            <div className="flex items-center text-sm text-gray-600 mb-3">
                                                <svg className="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                                                </svg>
                                                {bike.location}
                                            </div>

                                            <div className="items-center mb-4">
                                                <span className="text-lg font-bold">₹{bike.price?.perhour || 'N/A'}/hour</span>
                                                <span className="text-sm text-gray-500 ml-2">or ₹{bike.price?.perday || 'N/A'}/day</span>

                                                <button
                                                    onClick={() => handleView(bike._id)}
                                                    className={`mt-2 p-2 rounded-xl flex items-center justify-center w-full ${
                                                        isAvailable
                                                            ? 'bg-blue-600 text-white hover:bg-blue-700'
                                                            : isBooked
                                                                ? 'bg-gray-300 text-gray-600 cursor-not-allowed'
                                                                : 'bg-yellow-500 text-white hover:bg-yellow-600'
                                                    } transition-colors`}
                                                    disabled={!isAvailable}
                                                >
                                                    {isAvailable ? (
                                                        <>
                                                            View Packages
                                                            <svg className="w-4 h-4 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                                                            </svg>
                                                        </>
                                                    ) : isBooked ? (
                                                        'Already Booked'
                                                    ) : (
                                                        'Not Available'
                                                    )}
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                );
                            })
                        ) : (
                            <div className="col-span-full text-center py-10">
                                <div className="mx-auto w-24 h-24 mb-4 text-gray-400">
                                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                                    </svg>
                                </div>
                                <h3 className="text-lg font-medium text-gray-700 mb-1">No bikes found</h3>
                                <p className="text-gray-500 max-w-md mx-auto">
                                    Try adjusting your filters or search criteria to find what you're looking for.
                                </p>
                                <button
                                    onClick={() => setSelectedFilters({
                                        bookingDuration: '',
                                        transmissiontype: '',
                                        fueltype: '',
                                        vehicletype: '',
                                    })}
                                    className="mt-4 text-blue-600 hover:text-blue-800 text-sm font-medium"
                                >
                                    Clear all filters
                                </button>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
}

export default Packagesec1;