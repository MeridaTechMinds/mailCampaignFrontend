
"use client";

import React, { useState } from 'react';


const FilterContent = ({ selectedFilters, onFilterChange }) => {
   const handleRadioChange = (filterType, value) => {
    
    const lowerCaseValue = value.toLowerCase();
    console.log(`FilterContent: Changing ${filterType} to: ${lowerCaseValue}`);
    onFilterChange({ ...selectedFilters, [filterType]: lowerCaseValue });
};

    const handleClearFilters = () => {
        console.log("FilterContent: Clearing all filters.");
        onFilterChange({
            bookingDuration: '',
            transmissiontype: '', 
            fueltype: '',
            vehicletype: '',
        });
    };

    return (
        <div className="p-4 bg-white">
            <div className="flex justify-between items-center mb-4">
                <h2 className="text-2xl font-bold">Filters</h2>
                <button 
                    onClick={handleClearFilters}
                    className="text-sm text-blue-600 hover:text-blue-800"
                >
                    Clear all
                </button>
            </div>

            {/* Transmission Type Section */}
            <div className="mb-6">
                <h3 className="text-lg font-semibold mb-3">Transmission Type</h3>
                <div className="space-y-2">
                  
                    {['manual', 'automatic'].map((type, index) => (
                        <div key={index} className="flex items-center py-1">
                            <input
                                type="radio"
                                id={`transmission-${index}`}
                                name="transmission-type"
                                value={type}
                                className="form-radio h-4 w-4 text-black border-gray-300 focus:ring-black"
                                onChange={() => handleRadioChange('transmissiontype', type)} 
                                checked={selectedFilters.transmissiontype === type}
                            />
                            <label htmlFor={`transmission-${index}`} className="ml-2 text-gray-700">
                                {type}
                            </label>
                        </div>
                    ))}
                </div>
            </div>

            <hr className="my-4 border-gray-200" />

            {/* Fuel Type Section */}
            <div className="mb-6">
                <h3 className="text-lg font-semibold mb-3">Fuel Type</h3>
                <div className="space-y-2">
                   
                    {['petrol', 'electric'].map((type, index) => (
                        <div key={index} className="flex items-center py-1">
                            <input
                                type="radio"
                                id={`fuel-type-${index}`}
                                name="fuel-type"
                                value={type}
                                className="form-radio h-4 w-4 text-black border-gray-300 focus:ring-black"
                                onChange={() => handleRadioChange('fueltype', type)} 
                                checked={selectedFilters.fueltype === type}
                            />
                            <label htmlFor={`fuel-type-${index}`} className="ml-2 text-gray-700">
                                {type}
                            </label>
                        </div>
                    ))}
                </div>
            </div>

            <hr className="my-4 border-gray-200" />

            {/* Vehicle Type Section */}
            <div>
                <h3 className="text-lg font-semibold mb-3">Vehicle Type</h3>
                <div className="space-y-2">
                  
                    {['scooter', 'bike', 'electric'].map((type, index) => (
                        <div key={index} className="flex items-center py-1">
                            <input
                                type="radio"
                                id={`vehicle-type-${index}`}
                                name="vehicle-type"
                                value={type}
                                className="form-radio h-4 w-4 text-black border-gray-300 focus:ring-black"
                                onChange={() => handleRadioChange('vehicletype', type)} // Pass 'vehicletype' (lowercase)
                                checked={selectedFilters.vehicletype === type}
                            />
                            <label htmlFor={`vehicle-type-${index}`} className="ml-2 text-gray-700">
                                {type}
                            </label>
                        </div>
                    ))}
                </div>
            </div>
            

        </div>
    );
};


const FilterMenu = ({ selectedFilters, onFilterChange }) => {
    const [isMobileModalOpen, setIsMobileModalOpen] = useState(false);

    return (
        <>
      
            <button
                onClick={() => setIsMobileModalOpen(true)}
                className="md:hidden fixed bottom-6 left-6 bg-[#263069] text-white py-3 px-6 rounded-full shadow-lg z-30 flex items-center gap-2"
            >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M3 3a1 1 0 011-1h12a1 1 0 011 1v3a1 1 0 01-.293.707L12 11.414V15a1 1 0 01-.293.707l-2 2A1 1 0 018 17v-5.586L3.293 6.707A1 1 0 013 6V3z" clipRule="evenodd" />
                </svg>
                Filters
            </button>

          
            <div className="hidden lg:block p-4 shadow-lg rounded-lg border w-full">
                <FilterContent selectedFilters={selectedFilters} onFilterChange={onFilterChange} />
            </div>

            {isMobileModalOpen && (
                <div className="lg:hidden fixed inset-0 bg-black bg-opacity-50 z-[999] flex justify-end">
                    <div className="bg-white w-full max-w-sm h-full overflow-y-auto flex flex-col">
                        <div className="flex justify-between items-center p-4 border-b">
                            <h2 className="text-xl font-bold">Filters</h2>
                            <button
                                onClick={() => setIsMobileModalOpen(false)}
                                className="text-gray-500 hover:text-gray-700"
                            >
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                                </svg>
                            </button>
                        </div>
                        
                        <div className="flex-1 overflow-y-auto p-4">
                            <FilterContent selectedFilters={selectedFilters} onFilterChange={onFilterChange} />
                        </div>

                        <div className="sticky bottom-0 bg-white p-4 border-t shadow-md">
                            <button
                                onClick={() => setIsMobileModalOpen(false)} 
                                className="w-full bg-[#263069] text-white py-3 rounded-lg hover:bg-[#1a2350] transition-colors"
                            >
                                Apply Filters
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </>
    );
};

export default FilterMenu;