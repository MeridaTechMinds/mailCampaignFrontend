"use client"

import { Archivo } from "next/font/google";
import Image from "next/image";



const archivoBlack = Archivo({
  subsets: ["latin"],
  weight: "400",
});

function Offersec1(){
     const discountCodes = [
    { code: 'MBK100', title: 'Get Flat Rs.200 OFF', description: 'Get Flat Rs.200 off on orders above Rs.5,000' },
    { code: 'MBK101', title: 'Get Flat Rs.300 OFF', description: 'Get Flat Rs.300 off on orders above Rs.7,000' },
    { code: 'MBK102', title: 'Get Flat Rs.150 OFF', description: 'Get Flat Rs.150 off on orders above Rs.3,000' },
    { code: 'MBK103', title: 'Get Flat Rs.250 OFF', description: 'Get Flat Rs.250 off on orders above Rs.6,000' },
    { code: 'MBK104', title: 'Get Flat Rs.100 OFF', description: 'Get Flat Rs.100 off on orders above Rs.2,000' },
    { code: 'MBK105', title: 'Get Flat Rs.400 OFF', description: 'Get Flat Rs.400 off on orders above Rs.10,000' },
    { code: 'MBK106', title: 'Get Flat Rs.250 OFF', description: 'Get Flat Rs.50 off on orders above Rs.1,000' },
    { code: 'MBK107', title: 'Get Flat Rs.500 OFF', description: 'Get Flat Rs.500 off on orders above Rs.12,000' },
  ];
    return(
            <div className="relative h-auto z-20 py-10 px-3">
                   <p className={`text-3xl font-semibold ${archivoBlack.className}`}>Offers for you</p>
               <div className="grid  md:grid-cols-4 gap-10 p-5">
                   {discountCodes.map((offer,index)=>(
                       <div key={index} className="bg-gray-50 border border-gray-200 w-[105%] rounded-lg p-5 shadow-lg">
              <h2 className="text-xl font-bold text-[#00B8EF]">{offer.title}</h2>
              <p className="text-gray-600 my-2">{offer.description}</p>
              <Image src="/r15.png" width={210} height={50}/>
              <div className="bg-white border border-dashed border-[#00B8EF]  ml-20 py-2 px-4 rounded-md inline-block">
                <span className="font-mono font-bold text-[#00B8EF] text-lg">{offer.code}</span>
              </div>
            </div>
                ))}
               </div>
                
            </div>
    )
}

export default Offersec1