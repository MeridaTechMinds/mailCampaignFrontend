"use client";

import { useRouter } from "next/navigation";
import { useState, useEffect } from "react";
import { FaMapMarkerAlt } from "react-icons/fa";

export default function RentForm() {
  const [location, setLocation] = useState("Bangalore");
  const [startDateTime, setStartDateTime] = useState("");
  const [endDateTime, setEndDateTime] = useState("");
  const [duration, setDuration] = useState("1 Day");

  const router = useRouter();

  // Initialize dates when component mounts
  useEffect(() => {
    const now = new Date();
    const later = new Date();
    later.setDate(later.getDate() + 1);

    // Format as datetime-local input requires (YYYY-MM-DDTHH:MM)
    const formatDateTime = (date) => {
      const pad = (num) => num.toString().padStart(2, '0');
      return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(date.getMinutes())}`;
    };

    setStartDateTime(formatDateTime(now));
    setEndDateTime(formatDateTime(later));
  }, []);

  const calculateDuration = (start, end) => {
    const startDate = new Date(start);
    const endDate = new Date(end);
    const diffTime = Math.abs(endDate - startDate);
    const diffHours = Math.ceil(diffTime / (1000 * 60 * 60));
    
    if (diffHours < 24) {
      return `${diffHours} ${diffHours > 1 ? 'Hours' : 'Hour'}`;
    } else {
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      return `${diffDays} ${diffDays > 1 ? 'Days' : 'Day'}`;
    }
  };

  const handleStartDateTimeChange = (e) => {
    const value = e.target.value;
    setStartDateTime(value);
    
    // Ensure end datetime is after start datetime
    if (new Date(value) >= new Date(endDateTime)) {
      const newEndDate = new Date(value);
      newEndDate.setDate(newEndDate.getDate() + 1);
      const formatted = `${newEndDate.getFullYear()}-${(newEndDate.getMonth() + 1).toString().padStart(2, '0')}-${newEndDate.getDate().toString().padStart(2, '0')}T${newEndDate.getHours().toString().padStart(2, '0')}:${newEndDate.getMinutes().toString().padStart(2, '0')}`;
      setEndDateTime(formatted);
    }
    
    setDuration(calculateDuration(value, endDateTime));
  };

  const handleEndDateTimeChange = (e) => {
    const value = e.target.value;
    setEndDateTime(value);
    setDuration(calculateDuration(startDateTime, value));
  };

  const handleSearch = () => {
    // Convert to ISO strings for easier parsing
    const startISO = new Date(startDateTime).toISOString();
    const endISO = new Date(endDateTime).toISOString();

    const queryParams = new URLSearchParams({
      location,
      start: startISO,
      end: endISO,
      duration
    }).toString();

    router.push(`/bikepackage?${queryParams}`);
  };

  return (
    <div className="w-full md:w-[80%] space-y-3 p-5 bg-[#263069] text-white rounded-lg mx-auto">
      <h1 className="text-xl md:text-2xl font-bold mb-2 text-center">Commuting Made Easy</h1>
      <p className="text-base md:text-lg mb-6 text-center">Scooter/Scooty/Bike on Rent in Bangalore</p>

      <div className="space-y-4">
        {/* Location Section */}
        <div className="pb-4">
          <div className="relative mb-3 w-[90%] bg-white justify-between px-2 rounded-lg flex items-center">
            <select
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              className="w-[90%] text-black font-semibold outline-none p-2"
              disabled
            >
              <option value="Bangalore">Bangalore</option>
            </select>
            <FaMapMarkerAlt className="text-[#81E2FF]" />
          </div>

          <div className="grid grid-cols-1 gap-4">
            {/* Start Date/Time */}
            <div className="relative w-[90%]">
              <label className="block text-sm font-medium mb-1">Pickup Date & Time</label>
              <input
                type="datetime-local"
                value={startDateTime}
                onChange={handleStartDateTimeChange}
                min={new Date().toISOString().slice(0, 16)}
                className="bg-white font-semibold text-black outline-none p-2 rounded-lg w-full"
                required
              />
            </div>

            {/* End Date/Time */}
            <div className="relative w-[90%]">
              <label className="block text-sm font-medium mb-1">Drop-off Date & Time</label>
              <input
                type="datetime-local"
                value={endDateTime}
                onChange={handleEndDateTimeChange}
                min={startDateTime}
                className="bg-white font-semibold text-black outline-none p-2 rounded-lg w-full"
                required
              />
            </div>
          </div>
        </div>

        {/* Duration Section */}
        <div className="text-xl poppins pb-4">
          <span className="font-semibold">Duration: </span>
          <span>{duration}</span>
        </div>

        {/* Search Button */}
        <button
          onClick={handleSearch}
          className="w-[50%] md:w-[30%] lg:w-[20%] bg-[#81E2FF] text-black py-2 px-4 rounded font-medium flex items-center justify-center gap-2 mx-auto md:mx-0 cursor-pointer hover:bg-[#6dc8e3] transition-colors"
        >
          Search
        </button>
      </div>
    </div>
  );
}