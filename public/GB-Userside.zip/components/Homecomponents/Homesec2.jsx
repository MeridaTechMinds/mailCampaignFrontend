"use client";

import { Archivo } from "next/font/google";
import { useEffect, useState } from "react";
import axios from "axios";
import { useRouter } from "next/navigation";


const archivoBlack = Archivo({
  subsets: ["latin"],
  weight: "400",
});

function Homesec2() {
  const [rentalLocations, setRentalLocations] = useState([]);
  const [bikeBrands, setBikeBrands] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const router = useRouter()

  useEffect(() => {
    const fetchData = async () => {
      try {
       
        const response = await axios.get(`${process.env.NEXT_PUBLIC_PORT}/bikes`);
        const bikes = response.data;

  
        const locations = [...new Set(bikes
          .filter(bike => bike.location) 
          .map(bike => bike.location.trim()))] 
          .map(location => ({
            name: location || 'Unknown Location'
          }));

        
        const brands = [...new Set(bikes
          .filter(bike => bike.name) 
          .map(bike => bike.name.trim()))]
          .map(name => ({
            bikeName: name || 'Unknown Brand'
          }));

        setRentalLocations(locations);
        setBikeBrands(brands);
        setLoading(false);
      } catch (err) {
        setError(err.message || "Failed to fetch data");
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  if (loading) {
    return (
      <div className="py-10 px-5 bg-[#F7F7F7] text-center">
        <div className="inline-block animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-blue-500"></div>
        <p className="mt-2">Loading bike data...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="py-10 px-5 bg-[#F7F7F7] text-center">
        <p className="text-red-500 font-medium">Error loading data: {error}</p>
        <button 
          onClick={() => window.location.reload()}
          className="mt-2 px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600"
        >
          Try Again
        </button>
      </div>
    );
  }

  return (
    <div className={`py-10 px-5 bg-[#F7F7F7]`}>
      <h1 className={`text-center font-semibold bg-gradient-to-r from-[#263069] to-[#81E2FF] bg-clip-text text-transparent text-4xl mb-8 ${archivoBlack.className}`}>
        Bike Rental Locations in Bangalore
      </h1>

      <div className={`grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-2`}>
        {rentalLocations.length > 0 ? (
          rentalLocations.map((location, index) => (
            <div key={index} className="p-2 my-3 bg-white rounded shadow hover:shadow-md transition-shadow">
              <p className="text-center font-medium cursor-pointer mb-0" onClick={()=>router.push('/bikepackage')}>Bike location available on {location.name}</p>
            </div>
          ))
        ) : (
          <p className="col-span-full text-center my-3 text-gray-500 mb-0">No rental locations available</p>
        )}
      </div>

      <h1 className={`text-center font-semibold bg-gradient-to-r from-[#263069] to-[#81E2FF] bg-clip-text text-transparent text-4xl mb-4 mt-10 ${archivoBlack.className}`}>
        Bike Brands Available
      </h1>

      <div className={`grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-2`}>
        {bikeBrands.length > 0 ? (
          bikeBrands.map((brand, index) => (
            <div key={index} className="p-2 my-3 bg-white rounded shadow hover:shadow-md transition-shadow">
              <p className="text-center font-medium cursor-pointer mb-0" onClick={()=>router.push('/bikepackage')}>{brand.bikeName}</p>
            </div>
          ))
        ) : (
          <p className="col-span-full text-center my-3 text-gray-500 mb-0">No bike brands available</p>
        )}
      </div>
    </div>
  );
}

export default Homesec2;
