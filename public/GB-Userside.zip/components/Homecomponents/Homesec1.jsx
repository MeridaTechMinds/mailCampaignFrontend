"use client";

import Inputform from "./Inputform";

function Homesec1() {
  return (
    <div className="relative h-full flex ">
      <div className="m-auto w-full ">
        <Inputform/>
      </div>
    </div>
  );
}

export default Homesec1;